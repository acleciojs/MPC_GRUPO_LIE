# Correcao das duas versoes SQP-ADMM

## Causa exata do erro

As funcoes locais `try_reduced_trial` de **ambas** as versoes foram declaradas com as duas primeiras saidas invertidas. A funcao interna `update_nlp_exponential` retorna `[u_new,x_new,...]` (controles 8xN, estados 30x(N+1)), mas a declaracao original era `[x_new,u_new,...]`. Ao aceitar um passo, o controlador atribuía a trajetoria de estados a `u_bar` e os controles a `x_bar`.

Na iteracao SQP seguinte, a funcao `derivadas_globais_horizonte_NMPC` falhava no `assert(isequal(size(X),[30,N+1]) && isequal(size(U),[8,N]))`.

## Mudancas realizadas

1. Assinatura `try_reduced_trial` corrigida para `[u_new,x_new,m_new,alpha,ok,kind]` em **Stomberg e Liu-Jian**.
2. Validacao explicita das dimensoes de `x_bar` e `u_bar` antes de chamar o gerador de Hessiana.
3. Validacao das dimensoes de `unew` e `xnew` imediatamente antes de atualizar a SQP.

**Nenhuma funcao simbolica, Hessiana, gradiente, restricao ou atualizacao ADMM foi alterada.**

## Como executar

Copie os dois arquivos `.m` corrigidos para a pasta do projeto, substituindo os anteriores. Verifique se MATLAB esta resolvendo os arquivos corretos:

```matlab
which -all nmpc_multirotor_sqp_admm_stomberg
which -all nmpc_multirotor_sqp_admm_liu_jian
which -all derivadas_globais_horizonte_NMPC

cfg=struct('T_sim',4,'N',40,'M',8,'max_sqp',2,'plot_results',false);
A=nmpc_multirotor_sqp_admm_stomberg(cfg);
B=nmpc_multirotor_sqp_admm_liu_jian(cfg);
```

Se o MATLAB nao carregar as alteracoes devido a funcoes antigas em memoria, use `clear nmpc_multirotor_sqp_admm_stomberg nmpc_multirotor_sqp_admm_liu_jian` e tente novamente.

## Validacao

As alteracoes foram conferidas estaticamente no codigo-fonte. O controlador completo nao foi executado neste ambiente por falta das dependencias MATLAB/CasADi/modelo.
