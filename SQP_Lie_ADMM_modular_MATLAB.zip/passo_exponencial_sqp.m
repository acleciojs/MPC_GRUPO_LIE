function xnew = passo_exponencial_sqp(x,delta,exp_cfg)
% PASSO_EXPONENCIAL_SQP: atualizacao no produto R^q x G_1 x ... x G_p.
%
% exp_cfg.euclid_x_idx: indices ambientes das coordenadas Euclidianas.
% exp_cfg.euclid_d_idx: indices tangentes correspondentes.
%
% exp_cfg.groups(j).x_idx: indices ambientes de vec(X_j), POR COLUNAS.
% exp_cfg.groups(j).delta_idx: indices das coordenadas tangentes de X_j.
% exp_cfg.groups(j).basis: matriz r x r x d contendo a base S_j.
%
% Realiza X_j <- X_j*expm(sum_l delta_l*basis(:,:,l)).
% Nenhuma projecao nem reducao de passo. alpha_SQP=1.

x=x(:);delta=delta(:);xnew=x;
used=zeros(numel(delta),1);
if isfield(exp_cfg,'euclid_x_idx') && ~isempty(exp_cfg.euclid_x_idx)
    ix=exp_cfg.euclid_x_idx(:);
    id=exp_cfg.euclid_d_idx(:);
    assert(numel(ix)==numel(id),'Indices euclidianos incompatíveis');
    assert(all(id>=1 & id<=numel(delta)) && ...
           all(ix>=1 & ix<=numel(x)), ...
           'Indice euclidiano fora das dimensoes');
    used(id)=used(id)+1;
    xnew(ix)=xnew(ix)+delta(id);
end
if ~isfield(exp_cfg,'groups') || isempty(exp_cfg.groups)
    assert(all(used==1), 'Coordenadas tangentes sem mapeamento ou duplicadas');
    return;
end
for j=1:numel(exp_cfg.groups)
    q=exp_cfg.groups(j);
    ix=q.x_idx(:);id=q.delta_idx(:);B=q.basis;
    r=size(B,1);
    assert(size(B,2)==r && size(B,3)==numel(id), ...
        'Base da algebra mal dimensionada no grupo %d',j);
    assert(numel(ix)==r*r,'vec(X) deve ter r*r entradas no grupo %d',j);
    assert(all(id>=1 & id<=numel(delta)) && ...
           all(ix>=1 & ix<=numel(x)), ...
           'Indice de grupo fora das dimensoes');
    used(id)=used(id)+1;
    X=reshape(x(ix),r,r);
    Lie=zeros(r,r);
    for ell=1:numel(id)
        Lie=Lie+delta(id(ell))*B(:,:,ell);
    end
    Xnext=X*expm(Lie);
    xnew(ix)=Xnext(:);
end
assert(all(used==1), 'Coordenadas tangentes sem mapeamento ou duplicadas');
assert(all(isfinite(xnew)),'Passo exponencial produziu NaN/Inf');
end
