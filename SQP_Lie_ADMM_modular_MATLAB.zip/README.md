# SQP geométrica + QP por blocos + ADMM clássico (MATLAB/CasADi)

Arquivos:
- `sqp_lie_admm.m`: **função principal**; recebe `f`, `H`, `g`, `Jg`, `h`, `Jh`, `delta_sym`, `x_sym`, `x0`, índices de blocos, configuração do passo geométrico, opções.
- `decompor_qp_em_blocos.m`: converte o modelo da QP em QPs locais, sem perder acoplamentos entre blocos; cria matrizes de consenso por interseção.
- `resolver_admm_qps.m`: executa **externamente** o ADMM clássico; `rho` fixo, sem sobrerrelaxação, sem aceitação inexata.
- `passo_exponencial_sqp.m`: executa **externamente** o passo `X <- X*expm(sum delta_l B_l)` e os incrementos euclidianos.
- `montar_qp_central_de_blocos.m`: somente diagnóstico opcional, para comparar com o ADMM.
- `exemplo_sqp_lie_admm_SO2.m`: exemplo de otimização de horizonte temporal em `SO(2)` com dinâmica e desigualdades.

## Como executar

Coloque todos os `.m` no caminho do MATLAB e configure o CasADi e `quadprog` (Optimization Toolbox):

```matlab
out = exemplo_sqp_lie_admm_SO2();
```

Ou selecione `opts.qp_solver = 'qpoases'`, com o plugin de qpOASES da sua instalação CasADi MATLAB.

## Interface

```matlab
out = sqp_lie_admm(f_sym,H_sym,g_sym,Jg_sym,h_sym,Jh_sym, ...
    delta_sym,x_sym,x0,indices_blocos,exp_cfg,opts);
```

**Convenção crucial:** todas as expressões CasADi `f_sym`, `g_sym`, `h_sym` são **pullbacks** `f(R_x(delta))`, `g(R_x(delta))`, `h(R_x(delta))` em torno do ponto `x_sym`, não expressões apenas de `x_sym` sem depender de `delta_sym`. `H_sym` é a Hessiana do custo em relação a `delta_sym`; `Jg_sym`, `Jh_sym` são as Jacobianas das restrições também em relação a `delta_sym`. A função principal avalia tudo em `delta = 0` a cada SQP, e calcula o gradiente do objetivo diretamente de `f_sym`.

O problema tratado é `min f(x)`, sujeito a `g(x)=0`, `h(x)<=0`. Por convenção, `g` **é igualdade** e `h` **é desigualdade**.

Os `indices_blocos` são índices das variáveis tangentes globais; cada bloco inclui seu trecho do horizonte e as **variáveis de estado compartilhadas** no início/fim, quando for NMPC. Todas as entradas não nulas da Hessiana e todas as linhas de `Jg`,`Jh` precisam caber em algum bloco; caso contrário a função interrompe com erro de acoplamento não local. O método não promete decompor uma QP arbitrariamente densa em QPs menores preservando acoplamentos sem reformulação adicional.

### Mecanismos mantidos

- Passo SQP unitário; sem Armijo, trust region, filtro ou fallback.
- ADMM clássico; `rho` fixo, sem Nesterov, sem sobre-relaxação e sem aceitação aproximada.
- Regularização diagonal local: `H_i <- sym(H_i) + max(reg_base, reg_floor - lambda_min(H_i))*I`, unicamente para definir Hessiana PD no QP de cada bloco. Isso **modifica** a QP original e é aplicado da mesma forma à QP central da comparação.
- A solução da SQP **não é atualizada se ADMM não convergir**, e o resultado retorna `status='admm_nao_convergiu'`.

### Limitações

1. O código é **genérico na dimensão tangente e nas matrizes de Lie**, mas o usuário deve fornecer a base da álgebra de cada grupo e o mapa dos índices; não infere automaticamente a estrutura do seu quadrotor de 30 estados.
2. O exemplo SO(2) usa `sin(theta_relativa)` na igualdade geométrica, que descreve a cinemática localmente perto da identidade, mas não é uma restrição global inequívoca para rotações a diferenças grandes.
3. O ADMM requer convexidade estrita das **QPs locais** após regularização; isso não garante convergência global da SQP não linear com alpha=1.
4. A decomposição preserva exatamente a QP **regularizada**, não necessariamente a QP sem regularização.
5. `exemplo_sqp_lie_admm_SO2.m` é uma chamada SQP para um horizonte de NMPC, não um simulador em malha fechada: para MPC, aplique apenas o primeiro controle e avance a planta em um laço externo.
6. Não executei o MATLAB/CasADi neste ambiente. O código foi inspecionado estruturalmente e a álgebra da decomposição será verificada independentemente.
