# SQP geométrico + ADMM com recuperação dinâmica (versão experimental)

## Qual é a mudança principal?

Os incrementos dos estados calculados pelos blocos ADMM podem não estar em consenso após 3 iterações. Não os usamos diretamente para avaliar a direção SQP. Mantemos os incrementos de controle produzidos pelo ADMM e reconstruímos a sequência tangente `dq` pela **dinâmica linearizada**:

`Dnext_k*dq_{k+1} = -h0_k - Dcur_k*dq_k - Du_k*du_k`, com `dq_0=0`.

Essa operação não torna a QP ADMM ótima, mas elimina o defeito de dinâmica linearizada da direção, para o conjunto escolhido de `du`. O controlador só aceita a direção se ela tiver derivada do custo negativa e sua sequência de controle passar no rollout **não linear** com as restrições verificadas. O resultado deve ser chamado **passo SQP inexato**, não convergência ADMM.

## Modificações adicionais

- `N=40`, `dt=0.025` s: horizonte de **1 s** (antes 0,4 s). É uma *mudança de projeto*, não um mero ajuste numérico. A mesma discretização é usada na previsão e na planta simulada.
- `M=4` blocos temporais, 3 interfaces; antes havia 8 blocos e 7 interfaces. O custo de cada QP local aumenta, e não é garantido que o tempo total diminua.
- Custo terminal com erro intrínseco: diferença das 13 variáveis euclidianas, log de `R_ref'*R` em SO(3), quatro diferenças angulares em SO(2). Usa Hessiana Gauss–Newton positiva semidefinida e gradiente local via diferenças centrais no grupo.
- Gradiente terminal é incluído no adjunto do fallback de controle. Antes o adjunto começava com coestado final zero.
- ADMM sobre-relaxado (`alpha=1.5`), Nesterov desligado, orçamento progressivo `[3,5,10,18]` (máx. 36 iterações se o passo não for aceito); `rho` adaptativo a cada 4 iterações.
- Checagem de Jacobianas geométricas por diferenças finitas e consistência do custo ao primeiro SQP. Uma falha aborta com diagnóstico, em vez de gerar uma sequência incorreta.
- Diagnóstico opcional `quadprog` centralizado na primeira QP, para identificar se o problema vem do ADMM ou da modelagem do MPC.

## Executar

Coloque o código no diretório do projeto, onde estão as funções `Init`, `Equilibrio`, `IntegrationEuler`, `Attitude_error`, `project_euler_state_symbolic`, `derivadas_globais_horizonte_NMPC`, `derivadas_restricoes_NMPC` e o CasADi/qpoases.

```matlab
r = nmpc_multirotor_sqp_admm_robusto(struct('T_sim',60));
```

Para isolar ADMM de SQP usando o solver global (requer `quadprog`; é mais lento e só executado uma vez na primeira SQP):

```matlab
r = nmpc_multirotor_sqp_admm_robusto(struct( ...
    'T_sim',10,'central_diagnostic',true));
```

Para preservar o período original de 0,01 s, mas obter horizonte de 1 s, use `N=100, M=4, dt=0.01`; isso é significativamente mais pesado:

```matlab
r = nmpc_multirotor_sqp_admm_robusto(struct( ...
    'T_sim',10,'dt',0.01,'N',100,'M',4));
```

Para comparar efeito do terminal:

```matlab
r0 = nmpc_multirotor_sqp_admm_robusto(struct('T_sim',40,'terminal_gain',0));
r1 = nmpc_multirotor_sqp_admm_robusto(struct('T_sim',40,'terminal_gain',20));
```

## Sinais importantes

- `results.err`: erro de posição em malha fechada.
- `results.qp_slope`: derivada do custo na direção **dinamicamente reconstruída**. Para uma direção descentente deve ser negativa.
- `results.tangent_residual`: defeito máximo da dinâmica linearizada do incremento reconstruído. Deve ser próximo da precisão numérica.
- `results.r_norm`, `results.s_norm`: resíduos de ADMM divididos pelas tolerâncias. São **convergência do ADMM** somente se ambos ≤ 1.
- `results.gap`: desacordo local das cópias das interfaces. Pode permanecer grande em uma SQP inexata; o estado aplicado à planta é sempre calculado pelo rollout não linear.
- `results.step_kind`: `projetado-restaurado`, `gradiente-restaurado` ou `none`.
- `results.central_test`: status da QP centralizada opcional e defeitos de suas restrições.

## O que a versão não garante

- Não demonstramos que o ADMM converge em 3 iterações nem que o SQP está próximo da solução NLP.
- Aceitação de uma direção pela dinâmica não linear e redução do custo **não prova estabilidade recursiva**.
- Se a referência não for um equilíbrio exato de `IntegrationEuler`, a posição desejada pode ser inalcançável em regime permanente.
- O método não modela obstáculos como restrições; eles são apenas desenhados.
- O arquivo não foi executado em MATLAB neste ambiente; depende de arquivos externos do multirrotor. A projeção tangente e o custo terminal precisam ser validados contra a implementação exata das derivadas geométricas.
- Com ~0,6 s por amostra reportados anteriormente e período físico de 0,025 s, o código ainda **não é de tempo real**. É um protótipo de simulação/diagnóstico.

## Investigar se o controlador ainda não responde

1. Verifique `Teste geometria: h_FD`, `custo` e `gradiente`. Se falharem, conserte os geradores simbólicos externos; mais iterações ADMM não resolvem.
2. Verifique `Diagnostico equilibrio ||f(x_ref,u_hover)-x_ref||_inf`.
3. Se `qp_slope` é próximo de zero em todos os instantes, o horizonte/custo/gradientes não fornecem autoridade suficiente para mexer nos primeiros controles. Compare `terminal_gain=0` e `20`.
4. Se a QP centralizada também apresenta falha ou não gera direção descentente, não adianta tunar `rho`.
5. Se a QP centralizada funciona e os passos ADMM não, examine `r_norm`,`s_norm`, aumente progressivamente os orçamentos ou teste menos blocos. Nesterov vem por último e deve ser comparado com reinício.
