function teste_projecao_tangente()
% Teste INDEPENDENTE (sem CasADi) da eliminacao causal da dinamica
% linearizada usada pela nova versao. Nao testa o modelo completo.
rng(7);nx=20;nu=8;N=40;
A=0.96*eye(nx)+0.01*randn(nx,nx);
B=0.03*randn(nx,nu);
h0=1e-3*randn(nx,N);
du=0.1*randn(nu,N);
dq=zeros(nx,N+1); err=0;
for k=1:N
    Dcur=-A;Dnext=eye(nx);Du=-B;
    dq(:,k+1)=Dnext\(-h0(:,k)-Dcur*dq(:,k)-Du*du(:,k));
    r=Dcur*dq(:,k)+Dnext*dq(:,k+1)+Du*du(:,k)+h0(:,k);
    err=max(err,norm(r,inf));
end
fprintf('Defeito da direcao projetada: %.3e\n',err);
assert(err<1e-10,'Falha na recursao da dinamica linearizada');
end
