function results = nmpc_multirotor_sqp_admm_robusto(user_cfg)
% SQP geometrica + ADMM temporal com passo inexato viavel (versao de pesquisa).
% ESTADO: 30 variaveis fisicas; incrementos intrinsecos: 20.
% CONTROLE: 8 entradas. O estado e projetado em SO(3) x SO(2)^4.
% N=40 e M=4 por padrao; horizon 1 segundo (dt=0.025).
%
% DIFERENCA FUNDAMENTAL:
% 1. ADMM resolve QPs locais sem condensacao; 3 iteracoes inicialmente.
% 2. Reconstroi dq de du pela dinamica linearizada, removendo o defeito
%    tangente mesmo quando as copias das interfaces nao convergiram.
% 3. Aceita o passo somente apos verificar a descida do custo ORIGINAL
%    (incluindo custo terminal) por rollout nao linear e limites dos estados.
% 4. Continua o ADMM quando a direcao nao gera descida; fallback por
%    adjunto reduzido se nenhuma direcao e aceitavel.
% 5. Nesterov desligado; sobre-relaxacao e rho adaptativo sao opcionais.
%
% OBSERVACOES:
% - A direcao pode ser util ao MPC SEM ter resolvido a QP distribuida.
% - Rotulo 'passo inexato' NAO significa convergencia ADMM.
% - Custo terminal e Gauss-Newton local, sem prova de Lyapunov.
% - Nenhuma garantia de tempo real, de estabilidade ou de viabilidade
%   recursiva: dependem do modelo e do supervisor/terminal.
% - A Hessiana global e a do OBJETIVO; nao inclui Hessianas das restricoes.
% - Obstaculos sao apenas exibidos, nao otimizados.
%
% Requer: Init, Equilibrio, IntegrationEuler, Attitude_error, CasADi,
% qpoases, project_euler_state_symbolic,
% derivadas_globais_horizonte_NMPC e derivadas_restricoes_NMPC.

if nargin<1 || isempty(user_cfg), user_cfg=struct(); end
assert(isstruct(user_cfg), 'Parametro de entrada deve ser struct.');
clc; close all;

if ispc
    path_casadi = 'C:\Users\samsu\Dropbox\Aclecio\codigos-modelos\MPC\casadi-3.6.5-windows64-matlab2018b';
elseif isunix
    path_casadi = '/home/aclecio/Dropbox/Aclecio/codigos-modelos/MPC/casadi-3.6.5-linux64-matlab2018b';
else
    path_casadi = '';
end
if ~isempty(path_casadi) && exist(path_casadi, 'dir')
    addpath(path_casadi);
end
if exist('./Modelo', 'dir'), addpath('./Modelo'); end
if exist('./Obstaculo', 'dir'), addpath('./Obstaculo'); end
import casadi.*

%% ==================== PARAMETROS ====================
amost   = 0.025;  % Horizonte de 1 s com N=40. Antes: 0.4 s.
N       = 40;
M       = 4;     % Somente 3 interfaces de consenso.
estados = 30;
entradas= 8;
% Nao incluir os 9 elementos de R como 9 incrementos independentes.
% Cada estado possui 13 + 3 + 4 = 20 coordenadas tangentes.
nx_t = 20;
if isfield(user_cfg,'dt'), amost=user_cfg.dt; end
if isfield(user_cfg,'N'), N=user_cfg.N; end
if isfield(user_cfg,'M'), M=user_cfg.M; end
assert(mod(N,M)==0, 'N precisa ser divisivel por M.');
bs=N/M;

% 'global_direct': G_sym={G_0,...,G_N}, Hessiana simbolica GLOBAL;
%   use somente para horizontes pequenos: N=50 pode esgotar memoria.
% 'sparse_equivalent': MESMA Hessiana global simetrica do objetivo separavel,
%   montada por 28 coordenadas por estagio, sem dupla contagem.
% As duas opcoes usam SOMENTE o pullback simetrico (sem A_skew).
hessian_backend = 'sparse_equivalent';

Q = zeros(18,18);
Q(1,1)=35; Q(2,2)=35; Q(3,3)=50;
Q(4,4)=15; Q(5,5)=15; Q(6,6)=15;
Q(7,7)=50; Q(8,8)=50; Q(9,9)=50;
Q(10,10)=20; Q(11,11)=20; Q(12,12)=20; Q(13,13)=20;
Q(14,14)=40; Q(15,15)=40; Q(16,16)=40; Q(17,17)=40; Q(18,18)=40;
R = diag([0.001,0.001,0.001,0.001,0.05,0.05,0.05,0.05]);
% Terminal Gauss-Newton local nas 20 coordenadas intrinsecas.
% Nao alterar as dependencias externas de derivadas do custo por estagio.
terminal_gain = 20;
if isfield(user_cfg,'terminal_gain'), terminal_gain=user_cfg.terminal_gain; end
Wterm = terminal_gain * diag([diag(Q(1:13,1:13)); ...
    Q(14,14)*ones(3,1); diag(Q(15:18,15:18))]);
central_diagnostic = isfield(user_cfg,'central_diagnostic') && ...
                     logical(user_cfg.central_diagnostic);

x_r = zeros(estados,1);
x_r(1:3) = [10;10;10];
x_r = project_lie_state(full(Init(x_r)));
k1 = 10;
k2 = 10;

% A primeira meta e obter uma direcao descentente, NAO resolver toda QP.
% Com 20 blocos e apenas 3 iteracoes, o ADMM original nao convergia.
% M=4 e 40 passos -> 3 interfaces (em vez de 19 originalmente).
max_sqp      = 2;       % RTI=1 apos inicializacao
sqp_init_steps = 3;
tol_sqp      = 1e-2;

admm_opts = struct();
admm_opts.alpha = 1.5;             % sobre-relaxacao (1=classico)
admm_opts.tol_abs = 1e-3;
admm_opts.tol_rel = 2e-3;
admm_opts.min_iter = 2;
admm_opts.stop_inexact = false;    % parar cedo e decidido pela aceitacao do MPC
admm_opts.adapt_rho = true;
admm_opts.rho_mu = 4;
admm_opts.rho_tau = 1.5;
admm_opts.rho_min = 0.5;
admm_opts.rho_max = 200;
admm_opts.adapt_every = 4;        % CORRECAO: antes 5 > max_admm=3
admm_opts.warm_dw = true;
admm_opts.nesterov = false;        % opcional; ativar so apos comparar
admm_opts.momentum_max = 0.65;
admm_opts.restart_ratio = 1.05;
admm_budgets = [3 5 10 18];   % orcamentos incrementais: maximo 36 iteracoes
% Nao aceitar uma direcao ADMM com interfaces muito inconsistentes.
% Estes limiares sao parametros de engenharia, NAO certificados KKT.
admm_accept_pr_ratio = 5.0; % apenas diagnostico
admm_accept_du_ratio = 10.0; % apenas diagnostico
admm_accept_gap = 0.10; % apenas diagnostico
rho = 10;
n_adapt = 0;
dual_warm_factor = 0.65;
if isfield(user_cfg,'max_sqp'), max_sqp=user_cfg.max_sqp; end
if isfield(user_cfg,'sqp_init_steps'), sqp_init_steps=user_cfg.sqp_init_steps; end
if isfield(user_cfg,'alpha'), admm_opts.alpha=user_cfg.alpha; end
if isfield(user_cfg,'nesterov'), admm_opts.nesterov=logical(user_cfg.nesterov); end
if isfield(user_cfg,'adapt_rho'), admm_opts.adapt_rho=logical(user_cfg.adapt_rho); end
if isfield(user_cfg,'admm_budgets'), admm_budgets=user_cfg.admm_budgets; end
if isfield(user_cfg,'rho'), rho=user_cfg.rho; end
if isfield(user_cfg,'admm_accept_pr_ratio'), admm_accept_pr_ratio=user_cfg.admm_accept_pr_ratio; end
if isfield(user_cfg,'admm_accept_du_ratio'), admm_accept_du_ratio=user_cfg.admm_accept_du_ratio; end
if isfield(user_cfg,'admm_accept_gap'), admm_accept_gap=user_cfg.admm_accept_gap; end
assert(admm_opts.alpha>0 && admm_opts.alpha<2, 'alpha ADMM exige 0 < alpha < 2');
assert(all(admm_budgets>=1) && all(admm_budgets==floor(admm_budgets)), ...
    'Orcamentos de ADMM devem ser inteiros positivos.');

% Convexificacao dos subproblemas locais. Cada Hessiana e regularizada
% UMA VEZ por SQP (antes de iniciar o ADMM interno).
eig_floor      = 1e-5;
delta_base     = 1e-8;

% Globalizacao opcional. A RTI teorica costuma aceitar passo unitario;
% a busca linear aqui e uma protecao para a planta deste exemplo.
use_line_search = true;
alpha0         = 1.0;
alpha_min      = 2^(-10);
ls_beta        = 0.5;
max_ls         = 11;
armijo_c       = 1e-6;
merit_penalty  = 1e4;

% Limite de incremento por amostra de SQP (forcas, torques).
% Evita correcoes fisicamente enormes causadas por QP inexata.
trust_du = [8;8;8;8;0.45;0.45;0.45;0.45];

% Usuario: 2000 amostras. Para depurar, reduza temporariamente a 5 ou 20.
T_sim = 120;        % primeiro teste: 3 s com amost=0.025
if isfield(user_cfg,'T_sim'), T_sim=user_cfg.T_sim; end

x0_init = zeros(estados,1);
x0_init(1:3) = [1;1;3];
x0 = project_lie_state(full(Init(x0_init)));

u_hover = Equilibrio(x_r);
u_hover = full(u_hover(:));
assert(numel(u_hover)==entradas, 'Equilibrio deve retornar 8 entradas.');
u_0 = repmat(u_hover,1,N);

% Limites das entradas e dos estados.
u_min = [0;0;0;0; -2;-2;-2;-2];
u_max = [80;80;80;80; 2;2;2;2];
if any(u_hover<u_min-1e-8) || any(u_hover>u_max+1e-8)
    warning('O comando Equilibrio(x_r) esta fora dos limites de atuador.');
end
idx_bnd = 1:13;
x_min_b = [-50;-50;0; -20;-20;-20; -20;-20;-20; -20;-20;-20;-20];
x_max_b = [ 50; 50;50; 20; 20; 20;  20; 20; 20;  10; 10; 10; 10];
n_b = numel(idx_bnd);

% Apenas visualizacao: nao fazem parte das restricoes da NLP.
d_safe = 1.5;
pos_obs = [7 7 7; 3 3 3; 4 8 6; 9 9 9]';

fprintf('=== NMPC SQP-ADMM ROBUSTO | N=%d M=%d bs=%d | SQP<=%d ADMM<=%d ===\n', ...
    N,M,bs,max_sqp,sum(admm_budgets));
fprintf('Horizonte=%.3f s, ganho terminal=%.3g; rho=%.3g, piso=%.1e, LS=%d\n', ...
    N*amost,terminal_gain,rho,eig_floor,use_line_search);

%% ==================== CASADI / MODELO ====================
x_sym = SX.sym('x',estados);
u_sym = SX.sym('u',entradas);
fd_sym = project_euler_state_symbolic(IntegrationEuler(x_sym,u_sym,amost));
f_dyn = Function('f_dyn',{x_sym,u_sym},{fd_sym});
% Diagnostico essencial: um equilibrio de referencia deve ser fixo do modelo.
x_eq_next=project_lie_state(full(f_dyn(x_r,u_hover)));
eq_defect=norm(x_eq_next(:)-x_r(:),inf);
fprintf('Diagnostico equilibrio ||f(x_ref,u_hover)-x_ref||_inf = %.3e\n',eq_defect);
if eq_defect>1e-5
    warning(['Equilibrio() nao e um ponto fixo de IntegrationEuler no estado ' ...
             'de referencia. Esse erro impede rastreamento estacionario exato.']);
end
% A estrutura do custo e do grupo de Lie e GLOBAL em todo o horizonte.
% O gerador de restricoes calcula somente as Jacobianas de h e g.
geo = derivadas_restricoes_NMPC(amost,idx_bnd,x_min_b,x_max_b,u_min,u_max);
assert(geo.nx_t==nx_t && geo.nd==48,'Dimensoes incorretas nas restricoes');
obj_global = derivadas_globais_horizonte_NMPC( ...
    N,Q,R,k1,k2,hessian_backend,'jet2');
assert(obj_global.nd==nx_t*(N+1)+entradas*N, ...
    'A Hessiana global tem dimensao incorreta');
fprintf('Gerador global ativo: %s | modo=%s | d=%d\n', ...
    which('derivadas_globais_horizonte_NMPC'),hessian_backend,obj_global.nd);


% Cada bloco (inclusive o primeiro):
% w_i = [dq_0; ...; dq_bs; du_0; ...; du_(bs-1)]
% Todas as 20*(bs+1) correcoes de estado sao variaveis INDEPENDENTES.
% Para o primeiro bloco: dq_0=0 imposto como limite fixo.
% A dinamica linearizada tem nx_t*bs igualdades explicitas por bloco.
n_w = nx_t*(bs+1) + entradas*bs;
n_eq = nx_t*bs;
n_ineq = 2*n_b*(bs+1);
qp_all = make_qpsol('qp_fullspace',n_w,n_eq,n_ineq);
fprintf('QP NAO CONDENSADA: %d variaveis, %d eq. dinamicas, %d desigualdades por bloco.\n', ...
        n_w,n_eq,n_ineq);

%% ==================== MALHA FECHADA ====================
x_plant = x0;
u_bar = u_0;
% A politica de warm start guarda o dual das interfaces, nao os incrementos
% primais, que dependem da linearizacao na amostra anterior.
dual_cache = zeros(nx_t,M-1);
last_step_accepted = false;

log_x=zeros(estados,T_sim+1);
log_u=zeros(entradas,T_sim);
log_err=zeros(1,T_sim+1);
log_sqp=zeros(1,T_sim);
log_admm=zeros(1,T_sim);
log_r_pr=nan(1,T_sim);
log_r_du=nan(1,T_sim);
log_eps_pr=nan(1,T_sim);
log_eps_du=nan(1,T_sim);
log_admm_converged=false(1,T_sim);
log_rho=zeros(1,T_sim);
log_alpha=zeros(1,T_sim);
log_merit=zeros(1,T_sim);
log_delta=zeros(1,T_sim);
log_du=zeros(1,T_sim);
log_qpfail=false(1,T_sim);
log_steps_ok=zeros(1,T_sim);
log_step_kind=cell(1,T_sim);
log_hmax=zeros(1,T_sim);
log_gap=nan(1,T_sim);
log_r_norm=nan(1,T_sim);
log_s_norm=nan(1,T_sim);
log_time=zeros(1,T_sim);
log_admm_reason=cell(1,T_sim);
log_qp_pred=nan(1,T_sim);
log_qp_slope=nan(1,T_sim);
log_tangent_res=nan(1,T_sim);
central_test=struct('status','disabled','gap_direct',NaN,'cost_direct',NaN);

log_x(:,1)=x0;
log_err(1)=norm(x0(1:3)-x_r(1:3));
for t=1:T_sim
    tic_step=tic;

    % Warm-start do controle, e reconstruir TODA a trajetoria nominal.
    if t==1
        u_warm=u_bar;
    else
        u_warm=[u_bar(:,2:end) u_bar(:,end)];
    end
    u_bar=project_controls(u_warm,u_min,u_max);
    x_bar=simulate_plant(f_dyn,x_plant,u_bar);
    merit0=merit_trajectory(x_bar,u_bar,x_r,u_hover,Q,R,k1,k2, ...
                            idx_bnd,x_min_b,x_max_b,merit_penalty,Wterm);

    % O dual de consenso refere-se ao MESMO horizonte fisico transladado.
    % Interpolacao deslocada de uma amostra, com amortecimento.
    if last_step_accepted && t>1
        lambda0=shift_consensus_dual(dual_cache,bs,dual_warm_factor);
    else
        lambda0=zeros(nx_t,M-1);
    end
    % Multiplicadores dos dois lados de cada interface devem somar zero.
    seed0=make_admm_seed(nx_t,M,lambda0);

    r_pr=NaN; r_du=NaN; eps_pr=NaN; eps_du=NaN;
    it_admm=0; k_sqp=0; alpha_used=0; delta_max=0;
    du_inf=0; qp_failed=false; sqp_steps_accepted=0;
    step_kind='none'; max_h_this_sample=0; gap_cons=NaN;
    info=struct('converged',false,'reason','nao executado', ...
                'r_pr',NaN,'r_du',NaN,'eps_pr',NaN,'eps_du',NaN, ...
                'n_adapt',0,'ok',false,'iter',0);

    % RTI=1 em regime; SQP=2 somente nas primeiras amostras.
    sqp_budget=1 + (t<=sqp_init_steps && max_sqp>1);
    accepted_global=false;
    for k=1:sqp_budget
        k_sqp=k;
        if k>1
            x_bar=simulate_plant(f_dyn,x_plant,u_bar);
            merit0=merit_trajectory(x_bar,u_bar,x_r,u_hover,Q,R,k1,k2, ...
                                    idx_bnd,x_min_b,x_max_b,merit_penalty,Wterm);
            % Nao reutilizar o incremento primal da linearizacao anterior.
            seed0=make_admm_seed(nx_t,M,0.35*dual_cache);
        end
        [H_global,g_global,F_bar]=obj_global.eval(x_bar,u_bar,x_r,u_hover);
        % A funcao externa calcula SOMENTE custos de estagio. Completar
        % custo terminal nas ultimas 20 coordenadas INTRINSECAS.
        [g_terminal,H_terminal,~]= ...
            terminal_local_quadratic(x_bar(:,end),x_r,Wterm);
        id_end=nx_t*N+(1:nx_t);
        H_global(id_end,id_end)=H_global(id_end,id_end)+H_terminal;
        g_global(id_end)=g_global(id_end)+g_terminal;
        F_bar=F_bar+terminal_cost_num(x_bar(:,end),x_r,Wterm);
        assert(isequal(size(H_global),[obj_global.nd obj_global.nd]));
        assert(numel(g_global)==obj_global.nd && isfinite(F_bar));
        stage=prepare_geometric_stages(geo,g_global,x_bar,u_bar);
        max_h_this_sample=max(max_h_this_sample, ...
            max(cellfun(@(v) norm(v.h0,inf),stage)));
        if t==1 && k==1
            [geom_err,cost_err,grad_err]=geometry_consistency_test(geo,obj_global, ...
                x_bar,u_bar,x_r,u_hover,Q,R,k1,k2,stage,F_bar,g_global,Wterm);
            fprintf('Teste geometria: h_FD=%.2e; custo=%.2e; gradiente=%.2e\n', ...
                geom_err,cost_err,grad_err);
            if geom_err>1e-2 || grad_err>1e-2 || cost_err>1e-5
                error(['Jacobianas geometricas das restricoes inconsistentes. ' ...
                   'Corrija as derivadas / projetor / custo antes de ADMM.']);
            end
        end
        if t==1 && k==1 && max_h_this_sample>1e-3
            error(['Defeito no rollout de referencia maior que 1e-3: ' ...
                'o integrador nao coincide com o gerador das restricoes.']);
        end
        if t==1 && k==1 && max_h_this_sample>1e-5
            warning(['Defeito h0 do rollout > 1e-5: verifique se ' ...
                'derivadas_restricoes_NMPC e project_lie_state usam ' ...
                'a MESMA dinamica discreta/projecao.']);
        end

        blocks=cell(M,1);
        for i=1:M
            blocks{i}=build_block(i,M,bs,x_bar,u_bar,stage,geo, ...
                H_global,g_global,idx_bnd,x_min_b,x_max_b,u_min,u_max,trust_du);
            [blocks{i}.H,blocks{i}.delta_reg]= ...
                convexify_hessian(blocks{i}.H,eig_floor,delta_base);
            delta_max=max(delta_max,blocks{i}.delta_reg);
        end

        % Opcional: isolar o erro do ADMM comparando a QP CENTRALIZADA.
        if central_diagnostic && t==1 && k==1
            central_test=diagnose_central_qp(blocks,obj_global.nd);
            fprintf('Central QP: %s, violacao_max=%.3e\n', ...
                central_test.status,central_test.gap_direct);
        end
        % Parada de progresso: avaliar direcao corrigida pela DINAMICA.
        % Se nao ha descida do custo NONLINEAR, continuar ADMM com o mesmo QP.
        seed=seed0;
        accepted=false;
        local_pred=NaN; local_slope=NaN; tangent_res=NaN;
        for pass=1:numel(admm_budgets)
            [dw_local,z_delta,gs,ge,info,rho,seed]= ...
                solve_admm_qp_fast(blocks,qp_all,nx_t,entradas,bs,M, ...
                                   rho,seed,admm_budgets(pass),admm_opts);
            it_admm=it_admm+info.iter;
            n_adapt=n_adapt+info.n_adapt;
            r_pr=info.r_pr; r_du=info.r_du;
            eps_pr=info.eps_pr; eps_du=info.eps_du;
            if ~info.ok
                qp_failed=true;
                fprintf('  t=%d SQP=%d ADMM: %s\n',t,k,info.reason);
                break;
            end
            [~,delta_u,gap_cons]=recover_admm_increment( ...
                 blocks,dw_local,z_delta,nx_t,entradas,bs);
            du_inf=norm(delta_u(:),inf);
            % CORRECAO PRINCIPAL: os estados de fronteira de um ADMM
            % inexato NAO sao coerentes com as igualdades da dinamica.
            % Projeta-se a DIRECAO (nao as variaveis fisicas) na dinamica
            % linearizada, partindo do estado inicial fixo dq_0=0.
            [delta_q,tangent_res]=project_dynamics_tangent(stage,delta_u);
            d=[delta_q(:);delta_u(:)];
            local_slope=full(g_global(:)'*d);
            local_pred=full(local_slope+0.5*(d'*H_global*d));
            % Se a direcao projetada nao for de descida, continuar
            % ADMM na mesma QP; nunca confiar somente em alpha=1.
            if ~isfinite(local_slope) || local_slope>= ...
                    -1e-9*max(1,norm(g_global)*norm(d))
                fprintf('  ADMM %d: direcao projetada nao-descendente (%.2e), gap=%.2e\n', ...
                    it_admm,local_slope,gap_cons);
                continue;
            end
            % A busca linear compara SEMPRE o verdadeiro custo com rollout;
            % nao depende de obter residuo ADMM < tolerancia.
            [u_new,x_new,merit_new,alpha_trial,accepted,kind]= ...
                update_nlp_exponential(f_dyn,x_plant,x_bar,u_bar, ...
                    delta_q,delta_u,stage,merit0, ...
                    x_r,u_hover,Q,R,k1,k2,idx_bnd,x_min_b,x_max_b, ...
                    merit_penalty,u_min,u_max,use_line_search,alpha0, ...
                    alpha_min,ls_beta,max_ls,armijo_c, ...
                    false,Wterm,g_terminal);
            if accepted
                % Este e um passo SQP INEXATO, nunca reportar ADMM convergido.
                kind='projetado-restaurado';
                break;
            end
            if info.converged
                break; % QP convergiu, mas houve falha na globalizacao.
            end
        end

        if ~accepted
            % Correcao de shooting por adjunto: nao requer QP adicional.
            [u_new,x_new,merit_new,alpha_trial,accepted]= ...
                fallback_shooting_gradient(f_dyn,x_plant,x_bar,u_bar,stage,merit0, ...
                    x_r,u_hover,Q,R,k1,k2,idx_bnd,x_min_b,x_max_b, ...
                    merit_penalty,u_min,u_max,max_ls,ls_beta,Wterm,g_terminal);
            if accepted
                kind='gradiente-restaurado';
            end
        end
        if ~accepted
            fprintf('  t=%d SQP=%d: nenhuma direcao admissivel e descendente.\n',t,k);
            break;
        end

        alpha_used=alpha_trial;
        sqp_steps_accepted=sqp_steps_accepted+1;
        accepted_global=true;
        step_kind=kind;
        improvement=(merit0-merit_new)/max(1,abs(merit0));
        u_bar=u_new; x_bar=x_new; merit0=merit_new;

        % Sempre guardar dual apenas de QP bem resolvida o suficiente.
        if info.ok && isfinite(r_pr) && isfinite(eps_pr) && ...
                r_pr<=2*max(eps_pr,1e-10) && info.iter>0
            dual_cache=0.5*(ge(:,1:M-1)-gs(:,2:M));
        else
            dual_cache=zeros(nx_t,M-1);
        end
        if du_inf*alpha_trial<tol_sqp || improvement<5e-4
            break;
        end
    end

    last_step_accepted=accepted_global;
    if ~accepted_global && ~hard_bounds_ok(x_bar,idx_bnd,x_min_b,x_max_b,1e-6)
        warning('t=%d: sem passo aceito e previsao viola os limites de estado; controle nao certificado.',t);
    end
    u_apply=u_bar(:,1);
    x_plant=project_lie_state(full(f_dyn(x_plant,u_apply)));
    if any(~isfinite(x_plant))
        error('Planta produziu estado invalido no instante t=%d.',t);
    end
    log_x(:,t+1)=x_plant;
    log_u(:,t)=u_apply;
    log_err(t+1)=norm(x_plant(1:3)-x_r(1:3));
    log_sqp(t)=k_sqp;
    log_admm(t)=it_admm;
    log_r_pr(t)=r_pr; log_r_du(t)=r_du;
    log_eps_pr(t)=eps_pr; log_eps_du(t)=eps_du;
    log_admm_converged(t)=logical(info.converged);
    log_rho(t)=rho; log_alpha(t)=alpha_used;
    log_merit(t)=merit0; log_delta(t)=delta_max; log_du(t)=du_inf;
    log_qpfail(t)=qp_failed; log_steps_ok(t)=sqp_steps_accepted;
    log_step_kind{t}=step_kind; log_hmax(t)=max_h_this_sample;
    log_gap(t)=gap_cons;
    log_r_norm(t)=r_pr/max(eps_pr,1e-14);
    log_s_norm(t)=r_du/max(eps_du,1e-14);
    log_time(t)=toc(tic_step); log_admm_reason{t}=info.reason;
    log_qp_pred(t)=local_pred;
    log_qp_slope(t)=local_slope;
    log_tangent_res(t)=tangent_res;
    fprintf(['t=%4d | err=%.3e | SQP=%d ADMM=%d | ' ...
             'r/eps=%.2g s/eps=%.2g | rho=%.3g | alpha=%.3g | ' ...
             'reg=%.2e |du|=%.2e | modo=%s | ' ...
             'gap=%.2e | dJ/dalpha=%.2e | p=[%.2f %.2f %.2f] | %.2fs\n'], ...
            t,log_err(t+1),k_sqp,it_admm, ...
            log_r_norm(t),log_s_norm(t),rho,alpha_used, ...
            delta_max,du_inf,step_kind,gap_cons,local_slope, ...
            x_plant(1),x_plant(2),x_plant(3),log_time(t));
end

%% ==================== GRAFICOS ====================
figure('Position',[100 100 1300 850]);
subplot(2,2,1);
plot3(log_x(1,:),log_x(2,:),log_x(3,:),'b-', 'LineWidth',1.5);
hold on;
for j = 1:size(pos_obs,2)
    [XX,YY,ZZ] = sphere(20);
    surf(pos_obs(1,j)+d_safe*XX,pos_obs(2,j)+d_safe*YY, ...
         pos_obs(3,j)+d_safe*ZZ,'FaceAlpha',0.15, ...
         'EdgeColor','none','FaceColor','r','HandleVisibility','off');
end
plot3(x_r(1),x_r(2),x_r(3),'k*','MarkerSize',15);
grid on; axis equal; xlabel('x'); ylabel('y'); zlabel('z');
title('Trajetoria nao linear da planta');
legend('planta','referencia');

subplot(2,2,2);
plot((0:T_sim)*amost,log_x(1,:),'b-', ...
     (0:T_sim)*amost,log_x(2,:),'r-', ...
     (0:T_sim)*amost,log_x(3,:),'g-','LineWidth',1.2);
xlabel('t (s)'); ylabel('posicao'); title('Posicao');
legend('x','y','z'); grid on;

subplot(2,2,3);
for j = 1:4
    stairs((0:T_sim-1)*amost,log_u(j,:),'LineWidth',1);
    hold on;
end
xlabel('t (s)'); ylabel('forcas'); title('Entradas 1-4');
legend('u_1','u_2','u_3','u_4'); grid on;

subplot(2,2,4);
semilogy((0:T_sim)*amost,max(log_err,eps),'b-','LineWidth',1.5);
xlabel('t (s)'); ylabel('||p - p_{ref}||'); title('Erro de posicao');
grid on;

figure('Position',[150 150 1350 650]);
subplot(2,3,1);
stairs((0:T_sim-1)*amost,log_sqp,'LineWidth',1.2);
xlabel('t (s)'); ylabel('SQP'); title('Iteracoes SQP / MPC'); grid on;
subplot(2,3,2);
stairs((0:T_sim-1)*amost,log_admm,'LineWidth',1.2);
xlabel('t (s)'); ylabel('ADMM'); title('Iteracoes ADMM / MPC'); grid on;
subplot(2,3,3);
semilogy((0:T_sim-1)*amost,max(log_r_norm,eps),'LineWidth',1.2); hold on;
semilogy((0:T_sim-1)*amost,max(log_s_norm,eps),'LineWidth',1.2);
yline(1,'k--');
xlabel('t (s)'); ylabel('residuo/tolerancia'); title('Convergencia ADMM');
legend('r/eps-pr','s/eps-du','tolerancia'); grid on;
subplot(2,3,4);
plot((0:T_sim-1)*amost,log_rho,'LineWidth',1.2);
xlabel('t (s)'); ylabel('rho'); title('Penalidade'); grid on;
subplot(2,3,5);
stairs((0:T_sim-1)*amost,log_alpha,'LineWidth',1.2);
xlabel('t (s)'); ylabel('alpha'); title('Passo aceito SQP'); grid on;
subplot(2,3,6);
semilogy((0:T_sim-1)*amost,max(log_delta,eps),'LineWidth',1.2); hold on;
semilogy((0:T_sim-1)*amost,max(log_du,eps),'LineWidth',1.2);
xlabel('t (s)'); ylabel('norma'); title('Regularizacao e direcao');
legend('delta','||du||_inf'); grid on;

fprintf('\nErro final: %.4e\n',log_err(end));
fprintf('Mudancas de rho: %d | QPs com falha: %d\n', ...
        n_adapt,nnz(log_qpfail));
fprintf('Amostras com residuos ADMM abaixo da tolerancia: %d de %d\n', ...
        nnz(log_admm_converged),T_sim);
fprintf('Mediana SQP: %.1f, ADMM: %.1f; mediana tempo: %.3fs\n', ...
        median(log_sqp),median(log_admm),median(log_time));
results=struct('N',N,'M',M,'dt',amost, ...
    'total_qp_solves',M*sum(log_admm),'total_time',sum(log_time), ...
    'x',log_x,'u',log_u,'err',log_err, ...
    'sqp',log_sqp,'admm',log_admm,'r_pr',log_r_pr,'r_du',log_r_du, ...
    'eps_pr',log_eps_pr,'eps_du',log_eps_du, ...
    'r_norm',log_r_norm,'s_norm',log_s_norm,'converged',log_admm_converged, ...
    'rho',log_rho,'alpha',log_alpha,'merit',log_merit, ...
    'reg',log_delta,'du',log_du,'qpfail',log_qpfail, ...
    'step_kind',{log_step_kind},'gap',log_gap,'time',log_time, ...
    'qp_pred',log_qp_pred,'qp_slope',log_qp_slope, ...
    'tangent_residual',log_tangent_res,'central_test',central_test, ...
    'admm_reason',{log_admm_reason});
end

%% ==================== ADMM DA QP CONGELADA ====================
function seed=make_admm_seed(nx,M,lambda)
% Guardar apenas os duais unscaled. Todos os incrementos retornam a zero
% quando mudam as linearizacoes de SQP ou deslocamos a amostragem do MPC.
seed=struct();
seed.z=zeros(nx,M-1);
seed.gs=zeros(nx,M);
seed.ge=zeros(nx,M);
seed.ge(:,1:M-1)=lambda;
seed.gs(:,2:M)=-lambda;
seed.dw=[];
seed.count=0;
seed.z_hat=seed.z;
seed.gs_hat=seed.gs;
seed.ge_hat=seed.ge;
seed.theta_acc=1;
seed.merit_prev=inf;
end

function lambda_new=shift_consensus_dual(lambda_old,bs,damp)
% Novo horizonte: interface j refere-se ao tempo anterior j*bs+1.
% Interpolar entre os duais das interfaces antigas j e j+1.
[nx,nb]=size(lambda_old);
lambda_new=zeros(nx,nb);
eta=min(1,1/max(1,bs));
for j=1:nb
    a=lambda_old(:,j);
    b=lambda_old(:,min(nb,j+1));
    lambda_new(:,j)=damp*((1-eta)*a+eta*b);
end
end

function [dw_local,z,gamma_s,gamma_e,info,rho,seed]=solve_admm_qp_fast( ...
    blocks,qp_all,nx,nu,bs,M,rho,seed,iterations,opts)
% ADMM a dois blocos (todos w_i em paralelo, todos z_j por consenso).
% Sobre-relaxacao alpha aplicada SOMENTE nas copias que entram em z e nos
% duais; os residuos primais usam as copias originais X_e e X_s.
% Esta funcao pode ser chamada mais de uma vez na MESMA QP com seed.
if isempty(seed) || ~isstruct(seed)
    seed=make_admm_seed(nx,M,zeros(nx,M-1));
end
if isempty(seed.dw) || numel(seed.dw)~=M
    seed.dw=cell(M,1);
    for i=1:M, seed.dw{i}=zeros(blocks{i}.n_w,1); end
end
z=seed.z; gamma_s=seed.gs; gamma_e=seed.ge;
if ~isfield(seed,'z_hat') || ~isequal(size(seed.z_hat),size(z))
    seed.z_hat=z; seed.gs_hat=gamma_s; seed.ge_hat=gamma_e;
end
X_s=zeros(nx,M); X_e=zeros(nx,M);
dw_local=seed.dw;
info=struct('ok',true,'reason','budget','iter',0,'converged',false, ...
  'r_pr',inf,'r_du',inf,'eps_pr',inf,'eps_du',inf, ...
  'n_adapt',0,'residual_history',nan(iterations,2));

for l=1:iterations
    old_z=z;
    if opts.nesterov
        z_use=seed.z_hat;
        gs_use=seed.gs_hat;
        ge_use=seed.ge_hat;
    else
        z_use=z;
        gs_use=gamma_s;
        ge_use=gamma_e;
    end
    % P1: resolver todas as QPs locais com fronteiras antigas.
    for i=1:M
        b=blocks{i};
        z_s=[]; gamma_si=[]; z_e=[]; gamma_ei=[];
        if i>1
            z_s=z_use(:,i-1); gamma_si=gs_use(:,i);
        end
        if i<M
            z_e=z_use(:,i); gamma_ei=ge_use(:,i);
        end
        [H_aug,f_aug]=add_admm_terms(b,z_s,gamma_si,z_e,gamma_ei,rho);
        H_aug=0.5*(H_aug+H_aug');
        if any(~isfinite(H_aug(:))) || any(~isfinite(f_aug))
            info.ok=false; info.reason=sprintf('H/f nao finitos, bloco %d',i);
            seed.z=z;seed.gs=gamma_s;seed.ge=gamma_e;seed.dw=dw_local;
            return;
        end
        try
            if opts.warm_dw
                x0_qp=dw_local{i};
            else
                x0_qp=zeros(b.n_w,1);
            end
            sol=qp_all('x0',x0_qp, ...
                'p',[f_aug;H_aug(:);b.A_all(:)], ...
                'lbx',b.lb,'ubx',b.ub, ...
                'lbg',[b.b_eq;-inf(b.n_ineq,1)], ...
                'ubg',[b.b_eq;b.b_ineq]);
            dw=full(sol.x);
            st=qp_all.stats();
            if isfield(st,'success') && ~st.success
                error('qpoases retornou success=false.');
            end
            if numel(dw)~=b.n_w || any(~isfinite(dw))
                error('QP retornou direcao invalida.');
            end
        catch ME
            info.ok=false;
            info.reason=sprintf('bloco %d, iter %d: %s',i,l,ME.message);
            seed.z=z;seed.gs=gamma_s;seed.ge=gamma_e;seed.dw=dw_local;
            return;
        end
        % A din. linearizada deve permanecer satisfeita por bloco.
        err=norm(b.A_eq*dw-b.b_eq,inf);
        if ~isfinite(err) || err>max(1e-5,1e-5*norm(b.b_eq,inf))
            info.ok=false;
            info.reason=sprintf('bloco %d, igualdade %.3e',i,err);
            seed.z=z;seed.gs=gamma_s;seed.ge=gamma_e;seed.dw=dw_local;
            return;
        end
        dw_local{i}=dw;
        X_s(:,i)=b.L_s*dw;
        X_e(:,i)=b.L_e*dw;
    end

    % P2: consenso nas interfaces; usar as copias SOBRE-RELAXADAS.
    alpha=opts.alpha;
    Xehat=alpha*X_e(:,1:M-1)+(1-alpha)*z_use;
    Xshat=alpha*X_s(:,2:M)+(1-alpha)*z_use;
    z=0.5*(Xehat+Xshat)+0.5*(ge_use(:,1:M-1)+gs_use(:,2:M))/rho;

    % P3: dual nao escalado: gamma <- gamma + rho*(Xhat-z).
    gamma_e=ge_use;
    gamma_s=gs_use;
    gamma_e(:,1:M-1)=ge_use(:,1:M-1)+rho*(Xehat-z);
    gamma_s(:,2:M)=gs_use(:,2:M)+rho*(Xshat-z);

    % Residuos ORIGINAIS (sem relaxar) para criterio verdadeiro de consenso.
    re=X_e(:,1:M-1)-z;
    rs=X_s(:,2:M)-z;
    r_pr=sqrt(sum(re(:).^2)+sum(rs(:).^2));
    r_du=sqrt(2)*rho*norm(z-old_z,'fro');
    y2=sum(sum(X_e(:,1:M-1).^2))+sum(sum(X_s(:,2:M).^2));
    gamma2=sum(sum(gamma_e(:,1:M-1).^2))+ ...
           sum(sum(gamma_s(:,2:M).^2));
    ncopy=2*nx*(M-1);
    eps_pr=sqrt(ncopy)*opts.tol_abs+ ...
           opts.tol_rel*max(sqrt(y2),sqrt(2)*norm(z,'fro'));
    eps_du=sqrt(ncopy)*opts.tol_abs+opts.tol_rel*sqrt(gamma2);
    info.iter=l;
    info.r_pr=r_pr;info.r_du=r_du;
    info.eps_pr=eps_pr;info.eps_du=eps_du;
    info.residual_history(l,:)=[r_pr,r_du];
    seed.count=seed.count+1;
    converged=(r_pr<=eps_pr && r_du<=eps_du);
    info.converged=converged;

    % Nesterov com reinicio em caso de crescimento do residuo composto.
    % EXPERIMENTAL: o padrao permanece desligado para QPs com muitas caixas.
    if opts.nesterov
        score=sqrt((r_pr/max(eps_pr,eps))^2+ ...
                   (r_du/max(eps_du,eps))^2);
        if score>opts.restart_ratio*seed.merit_prev || ~isfinite(score)
            seed.z_hat=z; seed.gs_hat=gamma_s;seed.ge_hat=gamma_e;
            seed.theta_acc=1;
        else
            theta_next=(1+sqrt(1+4*seed.theta_acc^2))/2;
            beta=min(opts.momentum_max,(seed.theta_acc-1)/theta_next);
            seed.z_hat=z+beta*(z-old_z);
            seed.gs_hat=gamma_s+beta*(gamma_s-gs_use);
            seed.ge_hat=gamma_e+beta*(gamma_e-ge_use);
            seed.theta_acc=theta_next;
        end
        seed.merit_prev=score;
    end

    if converged && seed.count>=opts.min_iter
        info.reason='converged';
        break;
    end
    if opts.stop_inexact && seed.count>=opts.min_iter && ...
            r_pr<2*eps_pr && r_du<2*eps_du
        info.reason='inexact';
        break;
    end

    % Adaptar rho dentro do orcamento. Duais sao NAO escalados.
    if opts.adapt_rho && mod(seed.count,opts.adapt_every)==0
        rp=r_pr/max(eps_pr,eps);
        rd=r_du/max(eps_du,eps);
        rho_new=rho;
        if rp>opts.rho_mu*rd
            rho_new=min(rho*opts.rho_tau,opts.rho_max);
        elseif rd>opts.rho_mu*rp
            rho_new=max(rho/opts.rho_tau,opts.rho_min);
        end
        if abs(rho_new-rho)>1e-12
            rho=rho_new;
            info.n_adapt=info.n_adapt+1;
            if opts.nesterov
                seed.z_hat=z;seed.gs_hat=gamma_s;seed.ge_hat=gamma_e;
                seed.theta_acc=1;seed.merit_prev=inf;
            end
        end
    end
end
seed.z=z;seed.gs=gamma_s;seed.ge=gamma_e;seed.dw=dw_local;
end

%% ==================== ADMM: LAGRANGIANA AUMENTADA (SEM D) ====================
% Penalidade isotropica de consenso (D = I implicito).
% H_aug = H_f + rho*Ls*Ls + rho*Le*Le, quando aplicavel.
% Nao introduzir pesos D*D nas interfaces.
function [H,f] = add_admm_terms(b,z_s,gamma_s,z_e,gamma_e,rho)
H = b.H;
f = b.f;
if b.has_x_start
    Ls = b.L_s;
    H = H + rho*(Ls'*Ls);
    f = f + Ls'*(gamma_s-rho*z_s);
end
if ~isempty(z_e)
    Le = b.L_e;
    H = H + rho*(Le'*Le);
    f = f + Le'*(gamma_e-rho*z_e);
end
end

%% ==================== RECUPERACAO DOS INCREMENTOS ADMM ====================
function [dq,du,gap] = recover_admm_increment( ...
    blocks,dw_local,z,nq,nu,bs)
% Na formulacao NAO CONDENSADA, cada dq(k) e uma variavel da QP.
% Em cada interface, as duas copias locais sao substituidas pelo consenso z.
% Isso preserva a unicidade da direcao de estado, mas, com ADMM inexato,
% pode introduzir pequeno residuo nas igualdades dinamicas reconstruidas.
M=numel(blocks); N=M*bs;
dq=zeros(nq,N+1); du=zeros(nu,N);
gap=0;
for i=1:M
    b=blocks{i}; wi=dw_local{i}; k0=(i-1)*bs;
    for j=0:bs
        rr=j*nq+(1:nq);
        dloc=wi(rr);
        knode=k0+j+1;
        if i==1 && j==0
            dq(:,knode)=0;
        elseif j==0 && i>1
            gap=max(gap,norm(dloc-z(:,i-1),inf));
            dq(:,knode)=z(:,i-1);
        elseif j==bs && i<M
            gap=max(gap,norm(dloc-z(:,i),inf));
            dq(:,knode)=z(:,i);
        else
            dq(:,knode)=dloc;
        end
    end
    iu=b.u_off+(1:nu*bs);
    du(:,k0+(1:bs))=reshape(wi(iu),nu,bs);
end
dq(:,1)=0;
end

%% ==================== RETRACAO EXPONENCIAL ====================
function xn = retract_state_exponential(x,eta)
% x: 30 estados fisicos, eta: 20 incrementos INTRINSECOS.
% Convencao SO2: c=R11=cos(theta), s=R13=sin(theta).
assert(numel(x)==30 && numel(eta)==20);
x=x(:); eta=eta(:);
xn=x;
xn(1:13)=x(1:13)+eta(1:13);

% SO(3) do corpo: multiplicacao a direita pelo exp(so3).
Rk=reshape(x(14:22),3,3);
v=eta(14:16);
K=[ 0, -v(3), v(2); v(3), 0, -v(1); -v(2), v(1), 0 ];
Rn=Rk*expm(K);
xn(14:22)=Rn(:);

% SO(2)^4: exponencial exata por seno/cosseno.
for j=1:4
    ii=23+2*(j-1);
    c=x(ii); s=x(ii+1);
    ct=cos(eta(16+j)); st=sin(eta(16+j));
    xn(ii:ii+1)=[ct*c-st*s;st*c+ct*s];
end
end

%% ==================== MERITO COM DINAMICA ====================
function [J,defect] = merit_geometrico(f_dyn,xtr,u,xr,ur,Q,R,k1,k2, ...
                                      idx_bnd,x_min_b,x_max_b,sigma,Wterm)
% Usa distancias que NAO anulam artificialmente em rotações de 180 graus.
% A integracao numerica nominal e IntegrationEuler + projecao no grupo,
% como na rotina simulate_plant() da versao original.
J=merit_trajectory(xtr,u,xr,ur,Q,R,k1,k2, ...
                   idx_bnd,x_min_b,x_max_b,sigma,Wterm);
defect=0;
N=size(u,2);
for k=1:N
    xp=project_lie_state(full(f_dyn(xtr(:,k),u(:,k))));
    xn=xtr(:,k+1);
    if any(~isfinite(xp)) || any(~isfinite(xn))
        J=inf; defect=inf; return;
    end
    defect=defect+norm(xn(1:13)-xp(1:13),1);
    Rp=reshape(xp(14:22),3,3);
    Rn=reshape(xn(14:22),3,3);
    % Distancia cordal globalmente discriminante (zero apenas se iguais).
    defect=defect+norm(Rp-Rn,'fro');
    for j=1:4
        ii=23+2*(j-1);
        defect=defect+norm(xp(ii:ii+1)-xn(ii:ii+1),2);
    end
end
J=J+sigma*defect;
end

%% ==================== LINE SEARCH + RESTAURACAO DE VIABILIDADE ====================
function [u_new,x_new,merit_new,alpha_used,accepted,kind] = ...
    update_nlp_exponential( ...
      f_dyn,x_plant,x_bar,u_bar,dq,du,stage,merit0, ...
      xr,ur,Q,R,k1,k2,idx_bnd,x_min_b,x_max_b, ...
      sigma,u_min,u_max,use_ls,alpha0,alpha_min,beta,max_ls,armijo_c,try_exp,Wterm,gterm)
% Primeiro tenta o passo geometico de multiple-shooting. Se o ADMM ainda
% apresenta desacordo ou o passo produz defeitos dinamicos, restaura
% a viabilidade com rollout da PLANTA DISCRETA (controle por shooting).
N=size(u_bar,2);
assert(isequal(size(dq),[20 N+1]) && isequal(size(du),size(u_bar)));
u_new=u_bar; x_new=x_bar; merit_new=merit0;
alpha_used=0; accepted=false; kind='none';

slope=0;
for k=1:N
    step=[dq(:,k);dq(:,k+1);du(:,k)];
    slope=slope+stage{k}.grad_f(:)'*step;
end
slope=slope+gterm(:)'*dq(:,N+1);
if ~isfinite(slope), return; end

maxSO3=max(sqrt(sum(dq(14:16,:).^2,1)));
maxSO2=max(max(abs(dq(17:20,:))));
maxAngle=max(maxSO3,maxSO2);
angleLimit=0.5;
if ~use_ls, max_ls=1; end
alpha=alpha0;
for j=1:max_ls
    if alpha<alpha_min && use_ls, break; end
    if try_exp && alpha*maxAngle>angleLimit
        alpha=alpha*beta;
        continue;
    end
    ut=project_controls(u_bar+alpha*du,u_min,u_max);
    if norm(ut-u_bar,'fro')<1e-13
        alpha=alpha*beta;
        continue;
    end
    % Opcao A: somente se a QP atingiu consenso suficiente.
    % Inexato: ir DIRETO para rollout, reduzindo exponenciais e defeitos.
    if try_exp
    xt=x_bar;
    xt(:,1)=x_plant;
    for k=2:N+1
        xt(:,k)=retract_state_exponential(x_bar(:,k),alpha*dq(:,k));
    end
    if all(isfinite(xt(:)))
        [mt,defect]=merit_geometrico(f_dyn,xt,ut,xr,ur,Q,R,k1,k2, ...
                       idx_bnd,x_min_b,x_max_b,sigma,Wterm);
        req=merit0-armijo_c*alpha*max(0,-slope);
        % Exigir viabilidade dinamica para nao provocar h0 grande na
        % segunda SQP; com ADMM inexato, a retracao pode violar dinamica.
        if isfinite(mt) && defect<=1e-5 && ...
                bounds_guard(xt,x_bar,idx_bnd,x_min_b,x_max_b,1e-6) && ...
                mt<=req+1e-10
            u_new=ut; x_new=xt; merit_new=mt;
            alpha_used=alpha; accepted=true; kind='exponencial';
            return;
        end
    end
    end % try_exp
    % Opcao B: restaurar dinamica NAO LINEAR e preservar geometria pelo
    % integrador/projecao. A QP continuou sendo resolvida sem condensar.
    xr_trial=simulate_plant(f_dyn,x_plant,ut);
    mr=merit_trajectory(xr_trial,ut,xr,ur,Q,R,k1,k2, ...
                        idx_bnd,x_min_b,x_max_b,sigma,Wterm);
    % A derivada direcional da SQP multiple-shooting nao corresponde
    % necessariamente ao merito do shooting restaurado. Portanto aceitar
    % uma reducao verificada do merito real, sem Armijo enganoso.
    if isfinite(mr) && ...
            bounds_guard(xr_trial,x_bar,idx_bnd,x_min_b,x_max_b,1e-6) && ...
            mr < merit0-1e-10*max(1,abs(merit0))
        u_new=ut; x_new=xr_trial; merit_new=mr;
        alpha_used=alpha; accepted=true; kind='restaurado';
        return;
    end
    alpha=alpha*beta;
end
end

%% ==================== RECUPERACAO DE DESCIDA ====================
function [u_new,x_new,m_new,alpha_used,ok] = fallback_shooting_gradient( ...
    f_dyn,xplant,xbar,ubar,stage,merit0, ...
    xr,ur,Q,R,k1,k2,idx_bnd,xmin,xmax,sigma,umin,umax,max_ls,beta,Wterm,gterm)
% Gradiente reduzido aproximado obtido por adjunto discreto sobre
% Jh da dinamica intrinseca. Usado SOMENTE se a direcao ADMM falha.
N=size(ubar,2);
nu=size(ubar,1);
nt=size(stage{1}.Dcur,2);
p=gterm(:); % Coestado terminal: ausente na versao anterior.
g=zeros(nu,N);
for k=N:-1:1
    Dc=stage{k}.Dcur;
    Dn=stage{k}.Dnext;
    Du=stage{k}.Du;
    Ak=-(Dn\Dc);
    Bk=-(Dn\Du);
    gf=stage{k}.grad_f(:);
    % Custo por estagio; coestado p inicial ja inclui custo terminal
    g(:,k)=gf(2*nt+(1:nu))+Bk'*p;
    p=gf(1:nt)+Ak'*p;
end
u_new=ubar;
x_new=xbar;
m_new=merit0;
alpha_used=0;
ok=false;
if any(~isfinite(g(:))) || norm(g(:),inf)<1e-12, return; end

% Escalonamento por amplitude de controle: forcas e torques
range=max(umax-umin,1e-4);
cap=max(0.01,0.05*range);
dir=-bsxfun(@times,range.^2,g);
normscale=max(max(abs(bsxfun(@rdivide,dir,cap))));
if normscale<1e-14, return; end
dir=dir/max(1,normscale);

alpha=1;
for j=1:max(max_ls,12)
    ut=project_controls(ubar+alpha*dir,umin,umax);
    if norm(ut-ubar,'fro')<1e-13
        alpha=alpha*beta; continue;
    end
    xt=simulate_plant(f_dyn,xplant,ut);
    mt=merit_trajectory(xt,ut,xr,ur,Q,R,k1,k2, ...
                        idx_bnd,xmin,xmax,sigma,Wterm);
    if isfinite(mt) && bounds_guard(xt,xbar,idx_bnd,xmin,xmax,1e-6) && ...
            mt < merit0-1e-10*max(1,abs(merit0))
        u_new=ut; x_new=xt; m_new=mt;
        alpha_used=alpha; ok=true;
        return;
    end
    alpha=alpha*beta;
end
end

function J = merit_trajectory(xtr,u,xr,ur,Q,R,k1,k2, ...
                              idx_bnd,x_min_b,x_max_b,sigma,Wterm)
J = cost_traj(xtr,u,xr,ur,Q,R,k1,k2,Wterm);
X = xtr(idx_bnd,:);
v_lower = bsxfun(@minus,x_min_b,X);
v_upper = bsxfun(@minus,X,x_max_b);
v = sum(max(v_lower(:),0))+sum(max(v_upper(:),0));
J = J + sigma*v;
end

function ok=hard_bounds_ok(xtr,idx_bnd,xmin,xmax,tol)
% Viabilidade pontual dos estados em TODOS os nos da trajetoria.
X=xtr(idx_bnd,:);
lo=bsxfun(@minus,X,xmin);
hi=bsxfun(@minus,xmax,X);
ok=all(isfinite(X(:))) && min(lo(:))>=-tol && min(hi(:))>=-tol;
end

function ok=bounds_guard(xnew,xbase,idx_bnd,xmin,xmax,tol)
% Se o warm-start e viavel, exige manter viabilidade. Caso contrario,
% permite APENAS restauracao que reduza a violacao total sem piorar maxima.
% Nao e garantia de seguranca para estado inicialmente inviavel.
[vs0,vm0]=state_bound_violation(xbase,idx_bnd,xmin,xmax);
[vs1,vm1]=state_bound_violation(xnew,idx_bnd,xmin,xmax);
if vs0<=tol
    ok=isfinite(vs1) && vs1<=tol;
else
    ok=isfinite(vs1) && vs1<vs0-1e-9*max(1,vs0) && vm1<=vm0+tol;
end
end

function [total,vmax]=state_bound_violation(xtr,idx_bnd,xmin,xmax)
X=xtr(idx_bnd,:);
lo=max(0,bsxfun(@minus,xmin,X));
hi=max(0,bsxfun(@minus,X,xmax));
v=[lo(:);hi(:)];
if any(~isfinite(v))
    total=inf;vmax=inf;
else
    total=sum(v);vmax=max(v);
end
end

function u = project_controls(u,u_min,u_max)
u = bsxfun(@max,u,u_min);
u = bsxfun(@min,u,u_max);
end

%% ==================== HESSIANA PARA QPOASES ====================
function [Hreg,delta] = convexify_hessian(H,eig_floor,delta_base)
% qpoases resolve QP escalar: sua Hessiana relevante e simetrica.
% Regularizacao para manter as QPs locais convexas.
H=0.5*(H+H');
if any(~isfinite(H(:)))
    error('Hessiana SQP nao finita. Corrija a modelagem/custo.');
end
lambda_min = min(eig(H));
delta = max(delta_base,eig_floor-lambda_min);
Hreg = H + delta*eye(size(H));
Hreg = 0.5*(Hreg+Hreg');
end

%% ==================== CUSTOS ====================
function J = cost_stage_sym(x,u,xr,ur,Q,R,k1,k2)
phi_B  = Attitude_error(x(14:22),xr(14:22),k1,k2);
phi_a2 = Attitude_error(x(23:24),xr(23:24),k1,k2);
phi_a3 = Attitude_error(x(25:26),xr(25:26),k1,k2);
phi_a4 = Attitude_error(x(27:28),xr(27:28),k1,k2);
phi_a5 = Attitude_error(x(29:30),xr(29:30),k1,k2);
x_ = [x(1:13)-xr(1:13);phi_B;phi_a2;phi_a3;phi_a4;phi_a5];
J = x_'*Q*x_+(u-ur)'*R*(u-ur);
end

function J = cost_traj(xtr,u,xr,ur,Q,R,k1,k2,Wterm)
N = size(u,2);
J = 0;
for k = 1:N
    J = J + cost_stage_num(xtr(:,k),u(:,k),xr,ur,Q,R,k1,k2);
end
J=J+terminal_cost_num(xtr(:,end),xr,Wterm);
end

function J = cost_stage_num(x,u,xr,ur,Q,R,k1,k2)
phi_B  = Attitude_error(x(14:22),xr(14:22),k1,k2);
phi_a2 = Attitude_error(x(23:24),xr(23:24),k1,k2);
phi_a3 = Attitude_error(x(25:26),xr(25:26),k1,k2);
phi_a4 = Attitude_error(x(27:28),xr(27:28),k1,k2);
phi_a5 = Attitude_error(x(29:30),xr(29:30),k1,k2);
x_ = [x(1:13)-xr(1:13);phi_B;phi_a2;phi_a3;phi_a4;phi_a5];
J = x_'*Q*x_+(u-ur)'*R*(u-ur);
end

%% =========== RESTRICOES POR ESTAGIO, GRADIENTE GLOBAL ==============
function stage = prepare_geometric_stages(geo,g_global,xbar,ubar)
% Para o custo atual ell(x_k,u_k), o gradiente do estagio k e extraido
% diretamente de g_global. Nao existe custo em x_(k+1) nesse estagio.
% As Jacobianas h e g sao calculadas por estagio por eficiência.
N=size(ubar,2);
nt=geo.nx_t; nu=size(ubar,1);
assert(numel(g_global)==nt*(N+1)+nu*N);
stage=cell(N,1);
for k=1:N
    [Jh,h0,Jg,g0]=geo.lin(xbar(:,k),xbar(:,k+1),ubar(:,k));
    gf=[g_global((k-1)*nt+(1:nt)); ...
        zeros(nt,1); ...
        g_global(nt*(N+1)+(k-1)*nu+(1:nu))];
    stage{k}.Dcur=Jh(:,1:nt);
    stage{k}.Dnext=Jh(:,nt+(1:nt));
    stage{k}.Du=Jh(:,2*nt+(1:nu));
    stage{k}.h0=h0(:);
    stage{k}.Jg=Jg;
    stage{k}.g0=g0(:);
    stage{k}.grad_f=gf;
end
end

%% ================ QP LOCAL NAO CONDENSADA: T_i ===================
function b = build_block(i,M,bs,x_bar,u_bar,stage,geo, ...
                         H_global,g_global,idx_bnd,x_min_b,x_max_b,u_min,u_max,trust_du)
% A variavel global tem 20*(N+1)+8*N coordenadas:
% omega=[dq0;...;dqN;du0;...;du(N-1)].
% A variavel w_i da QP local e [dq_0;...;dq_bs;du_0;...;du_(bs-1)].
%
% T_i e a matriz de injecao 1420x76 definida por T_i(ids_global(j),j)=1.
% Portanto, T_i'*H_global*T_i == H_global(ids_global,ids_global).
% NAO precisa materializar T_i para montar a QP.
%
% Importante: como o custo original e ell(x_k,u_k) (NAO depende de x_next),
% a contribuicao do estado compartilhado no F GLOBAL pertence exclusivamente
% ao bloco que COMECA nesse estado. Por isso o ultimo estado dos blocos
% 1,...,M-1 nao recebe custo naquele bloco. O estado continua variavel e
% continua presente nas restricoes de dinamica e consenso.
nx=geo.nx_t; nu=size(u_bar,1);
N=size(u_bar,2);
k0=(i-1)*bs;
nstate=nx*(bs+1);
n_w=nstate+nu*bs;
n_eq=nx*bs;
nb=numel(idx_bnd);
n_ineq=2*nb*(bs+1);

% Indices da extracao GLOBAL (equivalente a T_i).
ids_global=zeros(n_w,1);
for j=0:bs
    ilocal=j*nx+(1:nx);
    iglobal=(k0+j)*nx+(1:nx);
    ids_global(ilocal)=iglobal;
end
for j=1:bs
    ilocal=nstate+(j-1)*nu+(1:nu);
    iglobal=nx*(N+1)+(k0+j-1)*nu+(1:nu);
    ids_global(ilocal)=iglobal;
end
assert(numel(unique(ids_global))==n_w);
H=full(H_global(ids_global,ids_global));
f=full(g_global(ids_global)); f=f(:);

if i<M
    ixend=bs*nx+(1:nx);
    % Validar que ell(x_k,u_k) nao possui acoplamento entre x_end e
    % variaveis de estagios anteriores dentro deste bloco. Se isto ocorrer,
    % a atribuicao do custo precisara ser generalizada (p.ex., custo x_next).
    other=setdiff(1:n_w,ixend);
    crossnorm=norm(H(ixend,other),'fro')+norm(H(other,ixend),'fro');
    assert(crossnorm<1e-8*max(1,norm(H,'fro')), ...
        ['Custo global possui acoplamento com fronteira final do bloco. ' ...
         'A decomposicao atual admite ell(x_k,u_k) sem acoplamento x_next.']);
    H(ixend,:)=0;
    H(:,ixend)=0;
    f(ixend)=0;
end

% Igualdades DINAMICAS explicitas: 20 por intervalo.
A_eq=zeros(n_eq,n_w);
b_eq=zeros(n_eq,1);
for j=1:bs
    st=k0+j;
    ixcur=(j-1)*nx+(1:nx);
    ixnext=j*nx+(1:nx);
    iu=nstate+(j-1)*nu+(1:nu);
    rr=(j-1)*nx+(1:nx);
    A_eq(rr,ixcur)=stage{st}.Dcur;
    A_eq(rr,ixnext)=stage{st}.Dnext;
    A_eq(rr,iu)=stage{st}.Du;
    b_eq(rr)=-stage{st}.h0(:);
end

% Limites de incremento dos controles.
lb=-inf(n_w,1); ub=inf(n_w,1);
for j=1:bs
    st=k0+j;
    iu=nstate+(j-1)*nu+(1:nu);
    lb(iu)=max(u_min-u_bar(:,st),-trust_du);
    ub(iu)=min(u_max-u_bar(:,st), trust_du);
end
if i==1
    lb(1:nx)=0;
    ub(1:nx)=0;
end

% Desigualdades de ESTADO por bloco: 2*13*(bs+1).
A_ineq=zeros(n_ineq,n_w);
b_ineq=zeros(n_ineq,1);
for j=0:bs
    knode=k0+j+1;
    ix=j*nx+(1:nx);
    [gk,Jgk]=geo.bound_eval(x_bar(:,knode));
    rr=2*nb*j+(1:2*nb);
    if i==1 && j==0
        % Estado inicial MEDIDO e FIXO: nao se pode impor sua correcao.
        % Se estiver fora da caixa, a restauracao trata o problema.
        A_ineq(rr,:)=0;
        b_ineq(rr)=inf;
    else
        A_ineq(rr,ix)=Jgk;
        b_ineq(rr)=-gk(:);
    end
end

Ls=zeros(nx,n_w);Le=zeros(nx,n_w);
Ls(:,1:nx)=eye(nx);
Le(:,bs*nx+(1:nx))=eye(nx);

b=struct();
b.H=H;b.f=f;
b.A_eq=A_eq;b.b_eq=b_eq;
b.A_ineq=A_ineq;b.b_ineq=b_ineq;
b.A_all=[A_eq;A_ineq];
b.n_eq=n_eq;b.n_ineq=n_ineq;b.n_w=n_w;
b.u_off=nstate;b.lb=lb;b.ub=ub;
b.L_s=Ls;b.L_e=Le;
b.has_x_start=(i>1);
b.block_id=i;
b.global_ids=ids_global;
end

%% ==================== SIMULACAO NAO LINEAR ====================
function x = simulate_plant(f_dyn,x0,u)
N = size(u,2);
nx = numel(x0);
x = zeros(nx,N+1);
x(:,1)=project_lie_state(x0);
for j=1:N
    x(:,j+1)=project_lie_state(full(f_dyn(x(:,j),u(:,j))));
end
end

function x = project_lie_state(x)
% Reprojeta SO(3) e normaliza os quatro pares SO(2) apos integracao.
% Para a formulacao SQP, isso mantem a trajetoria nominal sobre SO(3).
% A projecao polar/normalizacao altera a dinamica discreta da planta
% e deve ser omitida se IntegrationEuler ja tiver integrador geometrico.
% Valida a representacao SO(3) + quatro SO(2) como pares [R11;R13].
R=reshape(x(14:22),3,3);
[U,~,V]=svd(R);
D_rot=diag([1,1,sign(det(U*V'))]);
Rp=U*D_rot*V';
x(14:22)=Rp(:);
% SO(2): cada par q=[R11;R13]=[cos(theta);sin(theta)].
% Se o modelo utiliza R13=-sin(theta), e necessario inverter a convencao
% do incremento angular no gerador de derivadas e no residual.
for j=0:3
    ids=23+2*j+(0:1);
    q=x(ids);
    nq=hypot(q(1),q(2));
    if ~isfinite(nq) || nq<1e-10
        error('Par angular %d invalido: Init/IntegrationEuler deve fornecer [R11;R13] nao nulo.',j+1);
    end
    x(ids)=q/nq;
end
end

%% ==================== PROJECAO DINAMICA TANGENTE ====================
function [dq,err]=project_dynamics_tangent(stage,du)
% Projecao causal exata da direcao de controle no espaco tangente das
% igualdades lineares: A_k dq_k + B_k du_k + C_k dq_(k+1) = -h_k.
% Quando o rollout nominal e factivel h_k~=0 pequeno; nao omitir h_k.
N=size(du,2); nt=size(stage{1}.Dcur,2);
dq=zeros(nt,N+1);
err=0;
for k=1:N
    sk=stage{k};
    rhs=-sk.h0(:)-sk.Dcur*dq(:,k)-sk.Du*du(:,k);
    dq(:,k+1)=sk.Dnext\rhs;
    err=max(err,norm(sk.Dcur*dq(:,k)+ ...
        sk.Dnext*dq(:,k+1)+sk.Du*du(:,k)+sk.h0(:),inf));
end
end

%% ==================== TERMINAL NO GRUPO DE LIE ====================
function e=terminal_error(x,xr)
% Erro coordenado de Rr'R em SO(3); usa log principal (abaixo de pi).
% Nao interpretar SO3 como 9 variaveis Euclidianas.
e=zeros(20,1);
e(1:13)=x(1:13)-xr(1:13);
R=reshape(x(14:22),3,3);
Rr=reshape(xr(14:22),3,3);
E=Rr'*R;
a=max(-1,min(1,(trace(E)-1)*0.5));
theta=acos(a);
vee=[E(3,2)-E(2,3);E(1,3)-E(3,1);E(2,1)-E(1,2)];
if theta<1e-5
    e(14:16)=0.5*vee;
elseif abs(pi-theta)<1e-4
    % Proximo de 180 graus, log nao e unico. Gera erro de verificacao.
    error('Rotacao relativa proxima de 180 graus: terminal_error nao suave.');
else
    e(14:16)=theta/(2*sin(theta))*vee;
end
for j=1:4
    ii=23+2*(j-1);
    c=x(ii);s=x(ii+1);
    cr=xr(ii);sr=xr(ii+1);
    e(16+j)=atan2(s*cr-c*sr,c*cr+s*sr);
end
end

function J=terminal_cost_num(x,xr,Wterm)
e=terminal_error(x,xr);
J=e'*Wterm*e;
end

function [g,H,Je]=terminal_local_quadratic(x,xr,Wterm)
% Gauss-Newton na retracao: H=2J'WJ e positivo semidefinida.
% Gradiente e derivada de estados em 20 coordenadas intrinsecas.
nt=20;
e=terminal_error(x,xr);Je=zeros(nt,nt);
h=1e-6;
for j=1:nt
    v=zeros(nt,1);v(j)=h;
    ep=terminal_error(retract_state_exponential(x,v),xr);
    em=terminal_error(retract_state_exponential(x,-v),xr);
    Je(:,j)=(ep-em)/(2*h);
end
g=2*Je'*Wterm*e;
H=2*Je'*Wterm*Je;
H=0.5*(H+H');
end

%% ==================== TESTE DE CONSISTENCIA ====================
function [err,costerr,graderr]=geometry_consistency_test(geo,obj,xbar,ubar,xr,ur,Q,R,k1,k2,stage,F_with_terminal,g_global,Wterm)
% Um teste direcional garante que a geometria projetada e os Jacobianos
% intrinsecos das restricoes usam a MESMA convencao de perturbacao.
nt=geo.nx_t;
dq=sin((1:nt)');dq=dq/norm(dq);
dn=cos((1:nt)');dn=dn/norm(dn);
du=sin((1:size(ubar,1))');du=du/norm(du);
h=1e-5;
xp=retract_state_exponential(xbar(:,1),h*dq);
xm=retract_state_exponential(xbar(:,1),-h*dq);
xnp=retract_state_exponential(xbar(:,2),h*dn);
xnm=retract_state_exponential(xbar(:,2),-h*dn);
[~,hp]=geo.lin(xp,xnp,ubar(:,1)+h*du);
[~,hm]=geo.lin(xm,xnm,ubar(:,1)-h*du);
fd=(hp(:)-hm(:))/(2*h);
model=stage{1}.Dcur*dq+stage{1}.Dnext*dn+stage{1}.Du*du;
err=norm(fd-model,inf)/max(1,norm(fd,inf));
% Objetivo do usuario deve coincidir com o codigo externo de derivadas.
expected=cost_traj(xbar,ubar,xr,ur,Q,R,k1,k2,Wterm);
costerr=abs(expected-F_with_terminal)/max(1,abs(F_with_terminal));
% Conferir tambem o gradiente da funcao OBJETIVO na mesma retracao.
XP=xbar;XM=xbar;
XP(:,1)=xp; XM(:,1)=xm;
Fplus=cost_traj(XP,ubar,xr,ur,Q,R,k1,k2,Wterm);
Fminus=cost_traj(XM,ubar,xr,ur,Q,R,k1,k2,Wterm);
grad_fd=(Fplus-Fminus)/(2*h);
grad_sym=full(g_global(1:nt)'*dq);
graderr=abs(grad_fd-grad_sym)/max([1,abs(grad_fd),abs(grad_sym)]);
end

%% ==================== QP CENTRALIZADA: DIAGNOSTICO ====================
function result=diagnose_central_qp(blocks,nvar)
% Monta EXATAMENTE o mesmo QP convexificado dos blocos, identificando
% as variaveis duplicadas de fronteira. Executar apenas quando solicitado.
result=struct('status','quadprog indisponivel','gap_direct',NaN, ...
    'cost_direct',NaN,'eq_max',NaN,'ineq_max',NaN);
if exist('quadprog','file')~=2, return; end
H=sparse(nvar,nvar);f=zeros(nvar,1);
rowsEq={};valsEq={};rowsIn={};valsIn={};
lb=-inf(nvar,1);ub=inf(nvar,1);
for i=1:numel(blocks)
    b=blocks{i};ids=b.global_ids(:);
    H(ids,ids)=H(ids,ids)+sparse(b.H);
    f(ids)=f(ids)+b.f(:);
    AE=sparse(b.n_eq,nvar); AE(:,ids)=sparse(b.A_eq);
    AI=sparse(b.n_ineq,nvar); AI(:,ids)=sparse(b.A_ineq);
    rowsEq{end+1}=AE; valsEq{end+1}=b.b_eq(:);
    rowsIn{end+1}=AI; valsIn{end+1}=b.b_ineq(:);
    lb(ids)=max(lb(ids),b.lb(:));
    ub(ids)=min(ub(ids),b.ub(:));
end
Aeq=vertcat(rowsEq{:});beq=vertcat(valsEq{:});
A=vertcat(rowsIn{:}); b=vertcat(valsIn{:});
finite=isfinite(b); A=A(finite,:); b=b(finite);
try
    op=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
         'MaxIterations',300);
    [sol,ff,flag]=quadprog(0.5*(H+H'),f,A,b,Aeq,beq,lb,ub,[],op);
    result.status=sprintf('quadprog exitflag %d',flag);
    if ~isempty(sol)
        result.cost_direct=ff;
        result.eq_max=norm(Aeq*sol-beq,inf);
        if isempty(A),result.ineq_max=0;
        else,result.ineq_max=max([0;A*sol-b]);end
        result.gap_direct=max(result.eq_max,result.ineq_max);
    end
catch ME
    result.status=['Falha quadprog: ' ME.message];
end
end

%% ==================== SOLVER QP CASADI ====================
function solver = make_qpsol(name,n_w,n_eq,n_ineq)
% A QP recebe simultaneamente igualdades de dinamica e desigualdades.
% Ela NAO condensa nem elimina estados.
import casadi.*
ncons=n_eq+n_ineq;
w=MX.sym('w',n_w);
p=MX.sym('p',n_w+n_w*n_w+ncons*n_w);
gv=p(1:n_w);
Hm=reshape(p(n_w+1:n_w+n_w*n_w),n_w,n_w);
Am=reshape(p(n_w+n_w*n_w+1:end),ncons,n_w);
qp=struct('x',w,'p',p,'f',0.5*w'*Hm*w+gv'*w,'g',Am*w);
opts=struct('printLevel','none','error_on_fail',false);
solver=qpsol(name,'qpoases',qp,opts);
end
