function results = nmpc_multirotor_sqp_admm_stomberg(user_cfg)
% FULL MATLAB/CASADI implementation for the user's 30-state multirotor.
% STOMBERG
% The COST Hessian and gradient are UNCHANGED from the supplied program:
%   obj_global = derivadas_globais_horizonte_NMPC(N,Q,R,k1,k2,...,'jet2')
%   [H_global,g_global,F_bar] = obj_global.eval(x_bar,u_bar,x_r,u_hover)
% The constraints and their Jacobians are also UNCHANGED.
% IMPORTANT: this is a Hessian-APPROXIMATE adaptation, not a literal
% implementation of the convergence theorem in the cited paper.
% External dependencies: Init, Equilibrio, IntegrationEuler, Attitude_error,
% project_euler_state_symbolic, derivadas_restricoes_NMPC,
% derivadas_globais_horizonte_NMPC, symbolic_* and CasADi/qpoases.
if nargin < 1 || isempty(user_cfg), user_cfg=struct(); end
assert(isstruct(user_cfg),'user_cfg deve ser struct.');
if ispc
    path_casadi='C:\Users\samsu\Dropbox\Aclecio\codigos-modelos\MPC\casadi-3.6.5-windows64-matlab2018b';
else
    path_casadi='/home/aclecio/Dropbox/Aclecio/codigos-modelos/MPC/casadi-3.6.5-linux64-matlab2018b';
end
if isfield(user_cfg,'casadi_path'),path_casadi=user_cfg.casadi_path;end
if exist(path_casadi,'dir'),addpath(path_casadi);end
if exist('./Modelo','dir'),addpath('./Modelo');end
if exist('./Obstaculo','dir'),addpath('./Obstaculo');end
import casadi.*

%% Model/weights (same as original feedback file)
amost=0.01; N=40; M=8;
estados=30; entradas=8; nx_t=20;
if isfield(user_cfg,'dt'),amost=user_cfg.dt;end
if isfield(user_cfg,'N'),N=user_cfg.N;end
if isfield(user_cfg,'M'),M=user_cfg.M;end
assert(M>=2 && mod(N,M)==0,'N deve ser multiplo de M, com M>=2.');
bs=N/M;
hessian_backend='sparse_equivalent';
Q=zeros(18,18);
Q(1,1)=35; Q(2,2)=35; Q(3,3)=50;
Q(4,4)=15; Q(5,5)=15; Q(6,6)=15;
Q(7,7)=50; Q(8,8)=50; Q(9,9)=50;
Q(10,10)=20; Q(11,11)=20; Q(12,12)=20; Q(13,13)=20;
Q(14,14)=40; Q(15,15)=40; Q(16,16)=40; Q(17,17)=40; Q(18,18)=40;
R=diag([0.001,0.001,0.001,0.001,0.05,0.05,0.05,0.05]);
x_r=zeros(estados,1);
x_r(1:3)=[4;4;4];
if isfield(user_cfg,'ref_pos'),x_r(1:3)=user_cfg.ref_pos(:);end
x_r=project_lie_state(full(Init(x_r)));
k1=10;k2=10;
u_min=[0;0;0;0;-2;-2;-2;-2];
u_max=[80;80;80;80;2;2;2;2];
idx_bnd=1:13;
x_min_b=[-50;-50;0;-20;-20;-20;-20;-20;-20;-20;-20;-20;-20];
x_max_b=[50;50;50;20;20;20;20;20;20;10;10;10;10];
trust_du=[8;8;8;8;.45;.45;.45;.45];
merit_penalty=1e4;
eig_floor=1e-8;delta_base=1e-8;
use_line_search=true;alpha0=1;alpha_min=2^-10;
ls_beta=.5;max_ls=11;armijo_c=1e-6;
T_sim=80;max_sqp=3;
if isfield(user_cfg,'T_sim'),T_sim=user_cfg.T_sim;end
if isfield(user_cfg,'max_sqp'),max_sqp=user_cfg.max_sqp;end
if isfield(user_cfg,'trust_du'),trust_du=user_cfg.trust_du(:);end
assert(numel(trust_du)==entradas && all(trust_du>0));
plot_results=true;
if isfield(user_cfg,'plot_results'),plot_results=logical(user_cfg.plot_results);end
x0_init=zeros(estados,1);x0_init(1:3)=[1;1;1];
if isfield(user_cfg,'x0_pos'),x0_init(1:3)=user_cfg.x0_pos(:);end
x0=project_lie_state(full(Init(x0_init)));
u_hover=full(Equilibrio(x_r));u_hover=u_hover(:);
assert(numel(u_hover)==entradas,'Equilibrio deve retornar 8 entradas.');
if any(u_hover<u_min-1e-8) || any(u_hover>u_max+1e-8)
    warning('Equilibrio(x_r) fora dos limites de entradas.');
end

%% CasADi -- same symbolic construction as original
x_sym=SX.sym('x',estados);u_sym=SX.sym('u',entradas);
fd_sym=project_euler_state_symbolic(IntegrationEuler(x_sym,u_sym,amost));
f_dyn=Function('f_dyn',{x_sym,u_sym},{fd_sym});
x_eq_next=project_lie_state(full(f_dyn(x_r,u_hover)));
fprintf('Equilibrio: ||f_d(xr,ur)-xr||_inf=%.3e\n',norm(x_eq_next-x_r,inf));
geo=derivadas_restricoes_NMPC(amost,idx_bnd,x_min_b,x_max_b,u_min,u_max);
assert(geo.nx_t==nx_t && geo.nd==48);
obj_global=derivadas_globais_horizonte_NMPC( ...
    N,Q,R,k1,k2,hessian_backend,'jet2');
assert(obj_global.nd==nx_t*(N+1)+entradas*N);

n_w=nx_t*(bs+1)+entradas*bs;
n_eq=nx_t*bs;n_ineq=2*numel(idx_bnd)*(bs+1);
qp_all=make_qpsol('qp_fullspace',n_w,n_eq,n_ineq);

%% Logs and closed-loop state
x_plant=x0;u_bar=repmat(u_hover,1,N);
log_x=zeros(estados,T_sim+1);log_x(:,1)=x0;
log_u=zeros(entradas,T_sim);
log_err=zeros(1,T_sim+1);log_err(1)=norm(x0(1:3)-x_r(1:3));
log_sqp=zeros(1,T_sim);log_inner=zeros(1,T_sim);
log_r_norm=nan(1,T_sim);log_s_norm=nan(1,T_sim);
log_gap=nan(1,T_sim);log_kkt=nan(1,T_sim);
log_alpha=zeros(1,T_sim);log_time=zeros(1,T_sim);
log_rho=zeros(1,T_sim);log_kind=cell(1,T_sim);
log_budget=zeros(1,T_sim);log_warm=zeros(1,T_sim);
log_slope=nan(1,T_sim);log_tangent=nan(1,T_sim);

% lambda has one 20-dimensional multiplier per temporal interface.
lambda_cache=zeros(nx_t,M-1);lambda_valid=false;
rho=15;
if isfield(user_cfg,'rho'),rho=user_cfg.rho;end
assert(rho>0);

%% Method A: outer SQP and INNER consensus ADMM (Stomberg-inspired)
% No overwrite of the objective Hessian/gradient with a Lagrangian Hessian.
% Therefore its convergence theorem does NOT automatically apply.
method_name='Stomberg: SQP externo + ADMM interno';
rho_min=1;rho_max=200;
cfg=struct('budget_initial',60,'budget_min',8,'budget_max',120, ...
    'check_every',5,'min_iter',5,'rho_adapt',false, ...
    'rho_mu',5,'rho_tau',1.5,'rho_every',10, ...
    'tol_abs',1e-3,'tol_rel',2e-3, ...
    'ratio_early',3,'gap_early',.10,'kkt_early',.15, ...
    'gap_emergency',2.0,'good_required',3, ...
    'warm_dual_damping',.70,'max_sqp_steady',1, ...
    'steady_after',25);
keys=fieldnames(cfg);
for j=1:numel(keys)
    if isfield(user_cfg,keys{j}),cfg.(keys{j})=user_cfg.(keys{j});end
end
assert(cfg.budget_min>=1 && cfg.budget_max>=cfg.budget_initial && ...
    cfg.budget_initial>=cfg.budget_min);
budget=cfg.budget_initial;good_streak=0;
for t=1:T_sim
    tic_step=tic;
    if t>1,u_bar=[u_bar(:,2:end),u_bar(:,end)];end
    u_bar=project_controls(u_bar,u_min,u_max);
    x_bar=simulate_plant(f_dyn,x_plant,u_bar);
    merit0=merit_trajectory(x_bar,u_bar,x_r,u_hover,Q,R,k1,k2, ...
        idx_bnd,x_min_b,x_max_b,merit_penalty);
    if lambda_valid
        lambda0=shift_consensus_dual(lambda_cache,bs,cfg.warm_dual_damping);
    else
        lambda0=zeros(nx_t,M-1);
    end
    log_warm(t)=norm(lambda0,'fro');
    log_budget(t)=budget;
    sqp_budget=max_sqp;
    if t>cfg.steady_after,sqp_budget=min(sqp_budget,cfg.max_sqp_steady);end
    accepted_global=false;used_inner=0;
    gap=inf;ratio_r=inf;ratio_s=inf;kkt=nan;
    kind='none';alpha_used=0;slope=nan;tangent=nan;
    for k=1:sqp_budget
        [H_global,g_global,F_bar]=obj_global.eval(x_bar,u_bar,x_r,u_hover);
        assert(isequal(size(H_global),[obj_global.nd,obj_global.nd]));
        assert(numel(g_global)==obj_global.nd && isfinite(F_bar));
        stage=prepare_geometric_stages(geo,g_global,x_bar,u_bar);
        blocks=cell(M,1);
        for i=1:M
            blocks{i}=build_block(i,M,bs,x_bar,u_bar,stage,geo, ...
                H_global,g_global,idx_bnd,x_min_b,x_max_b,u_min,u_max,trust_du);
            [blocks{i}.H,blocks{i}.delta_reg]= ...
                convexify_hessian(blocks{i}.H,eig_floor,delta_base);
        end
        seed=stomberg_seed(nx_t,M,lambda0);
        found=false;best_m=inf;
        info=struct('ok',true,'iter',0,'converged',false,'r_pr',inf, ...
            'r_du',inf,'eps_pr',1,'eps_du',1,'kkt',nan,'reason','');
        for l=1:budget
            [ws,seed,info,rho]=stomberg_inner_step( ...
                blocks,qp_all,seed,rho,cfg,rho_min,rho_max);
            if ~info.ok
                fprintf('  t=%d k=%d QP falhou: %s\n',t,k,info.reason);
                break;
            end
            used_inner=used_inner+1;
            ratio_r=info.r_pr/max(info.eps_pr,eps);
            ratio_s=info.r_du/max(info.eps_du,eps);
            [du,gap]=local_controls_and_gap(blocks,ws,seed.z,entradas,bs);
            kkt=info.kkt;
            if mod(l,cfg.check_every)~=0 && ~info.converged && l<budget
                continue;
            end
            [dq,tangent]=reconstruct_intrinsic(stage,du);
            if ~isfinite(tangent),continue;end
            slope=trajectory_slope(stage,dq,du);
            if ~isfinite(slope) || slope>=-1e-11
                if info.converged,break;end
                continue;
            end
            early=info.converged || ...
                (l>=cfg.min_iter && ratio_r<=cfg.ratio_early && ...
                 ratio_s<=cfg.ratio_early && gap<=cfg.gap_early && ...
                 (isfinite(kkt) && kkt<=cfg.kkt_early));
            if early || l==budget
                % If budget is exhausted, permit an independently verified
                % nonlinear descent from controls, but DO NOT call it converged.
                if gap>cfg.gap_emergency && ~early,continue;end
                [ut,xt,mt,at,ok,kn]=try_reduced_trial( ...
                    f_dyn,x_plant,x_bar,u_bar,stage,dq,du,merit0, ...
                    x_r,u_hover,Q,R,k1,k2,idx_bnd,x_min_b,x_max_b, ...
                    merit_penalty,u_min,u_max,use_line_search,alpha0, ...
                    alpha_min,ls_beta,max_ls,armijo_c);
                if ok && mt<best_m
                    best_m=mt;best=struct('u',ut,'x',xt,'merit',mt,'alpha',at, ...
                        'kind',kn,'early',early,'seed',seed,'info',info);
                    found=true;
                    if early,break;end
                end
            end
            if info.converged,break;end
        end
        if found
            unew=best.u;xnew=best.x;mnew=best.merit;
            alpha_used=best.alpha;
            if best.early
                kind='admm-consenso-restaurado';
            else
                kind='admm-inexato-validado';
            end
            % Dual transport is credible only when primal/dual residuals are OK.
            seed=best.seed;
            if best.info.r_pr<=5*best.info.eps_pr && ...
               best.info.r_du<=5*best.info.eps_du && gap<=.25
                lambda_cache=.5*(seed.ge(:,1:M-1)-seed.gs(:,2:M));
                lambda_valid=true;
            else
                lambda_valid=false;
            end
            accepted=true;
        else
            [unew,xnew,mnew,alpha_used,accepted]= ...
                fallback_shooting_gradient(f_dyn,x_plant,x_bar,u_bar, ...
                    stage,merit0,x_r,u_hover,Q,R,k1,k2, ...
                    idx_bnd,x_min_b,x_max_b,merit_penalty, ...
                    u_min,u_max,max_ls,ls_beta);
            if accepted,kind='gradiente-restaurado';end
            lambda_valid=false;
        end
        if ~accepted,break;end
        accepted_global=true;
        improvement=(merit0-mnew)/max(1,abs(merit0));
        u_bar=unew;x_bar=xnew;merit0=mnew;
        if improvement<1e-8 && k>=2,break;end
        lambda0=zeros(nx_t,M-1); % changed QP linearization
    end
    u_apply=u_bar(:,1);
    x_plant=project_lie_state(full(f_dyn(x_plant,u_apply)));
    if any(~isfinite(x_plant)),error('Estado da planta invalido.');end
    log_x(:,t+1)=x_plant;log_u(:,t)=u_apply;
    log_err(t+1)=norm(x_plant(1:3)-x_r(1:3));
    log_inner(t)=used_inner;log_sqp(t)=k;
    log_r_norm(t)=ratio_r;log_s_norm(t)=ratio_s;
    log_gap(t)=gap;log_kkt(t)=kkt;
    log_alpha(t)=alpha_used;log_rho(t)=rho;
    log_kind{t}=kind;log_time(t)=toc(tic_step);
    log_slope(t)=slope;log_tangent(t)=tangent;
    good=accepted_global && ~strcmp(kind,'gradiente-restaurado') && ...
       ratio_r<=cfg.ratio_early && ratio_s<=cfg.ratio_early && ...
       gap<=cfg.gap_early;
    if good
        good_streak=good_streak+1;
        if good_streak>=cfg.good_required
            budget=max(cfg.budget_min,budget-4);
            good_streak=0;
        end
    else
        good_streak=0;
        budget=min(cfg.budget_max,budget+8);
    end
    fprintf(['Stomberg t=%3d err=%.3g SQP=%d ADMM=%d | ' ...
       'r/eps=%.2g s/eps=%.2g gap=%.2g KKT_QP=%.2g ' ...
       'alpha=%.3g warm=%.1e modo=%s | %.2fs\n'], ...
       t,log_err(t+1),k,used_inner,ratio_r,ratio_s,gap,kkt, ...
       alpha_used,log_warm(t),kind,log_time(t));
end

%% Summaries and plots
fprintf('\nFinal error %.4e | median inner %.1f | median time %.3f s\n', ...
    log_err(end),median(log_inner),median(log_time));
results=struct('method',method_name,'x',log_x,'u',log_u,'err',log_err, ...
    'sqp',log_sqp,'inner',log_inner,'gap',log_gap,'kkt',log_kkt, ...
    'r_norm',log_r_norm,'s_norm',log_s_norm,'alpha',log_alpha, ...
    'rho',log_rho,'budget',log_budget,'warm',log_warm, ...
    'step_kind',{log_kind},'time',log_time,'slope',log_slope, ...
    'tangent_residual',log_tangent,'N',N,'M',M,'dt',amost);
if plot_results
    figure('Name',method_name,'Position',[120 120 1250 750]);
    subplot(2,3,1);plot3(log_x(1,:),log_x(2,:),log_x(3,:),'LineWidth',1.2);
    grid on;axis equal;xlabel('x');ylabel('y');zlabel('z');title('Planta nao linear');
    subplot(2,3,2);plot((0:T_sim)*amost,log_x(1:3,:)','LineWidth',1.0);
    grid on;title('Posicao');legend('x','y','z');
    subplot(2,3,3);semilogy((0:T_sim)*amost,max(log_err,eps),'LineWidth',1.2);
    grid on;title('Erro de posicao');
    subplot(2,3,4);stairs(log_inner);grid on;title('Iteracoes internas / varreduras');
    subplot(2,3,5);semilogy(max(log_gap,eps));grid on;title('Gap consenso');
    subplot(2,3,6);stairs(log_alpha);grid on;title('Passo SQP');
end
end

%% ADMM for a FROZEN geometric QP (Method A)
function seed=stomberg_seed(nx,M,lambda)
seed.z=zeros(nx,M-1);
seed.gs=zeros(nx,M);seed.ge=zeros(nx,M);
seed.ge(:,1:M-1)=lambda;
seed.gs(:,2:M)=-lambda;
seed.dw=cell(M,1);seed.lg=cell(M,1);seed.lx=cell(M,1);
seed.count=0;
for i=1:M
    seed.dw{i}=[];seed.lg{i}=[];seed.lx{i}=[];
end
end

function [dw,seed,info,rho]=stomberg_inner_step( ...
    blocks,qp,seed,rho,cfg,rho_min,rho_max)
M=numel(blocks);nx=size(blocks{1}.L_e,1);
if seed.count==0
    for i=1:M,seed.dw{i}=zeros(blocks{i}.n_w,1);end
end
old_z=seed.z;
info=struct('ok',true,'reason','','r_pr',inf,'r_du',inf, ...
    'eps_pr',inf,'eps_du',inf,'iter',0,'converged',false,'kkt',nan);
Xs=zeros(nx,M);Xe=zeros(nx,M);
for i=1:M
    b=blocks{i};H=b.H;f=b.f;
    if i>1
        H=H+rho*(b.L_s'*b.L_s);
        f=f+b.L_s'*(seed.gs(:,i)-rho*seed.z(:,i-1));
    end
    if i<M
        H=H+rho*(b.L_e'*b.L_e);
        f=f+b.L_e'*(seed.ge(:,i)-rho*seed.z(:,i));
    end
    H=.5*(H+H');
    [wi,lgi,lxi,ok,msg]=solve_local_qp(qp,b,H,f,seed.dw{i});
    if ~ok
        info.ok=false;info.reason=sprintf('bloco %d: %s',i,msg);
        dw=seed.dw;return;
    end
    seed.dw{i}=wi;seed.lg{i}=lgi;seed.lx{i}=lxi;
    Xs(:,i)=b.L_s*wi;Xe(:,i)=b.L_e*wi;
end
% Standard ADMM projection and unscaled dual update, rho constant default.
seed.z=.5*(Xe(:,1:M-1)+Xs(:,2:M)) + ...
    .5*(seed.ge(:,1:M-1)+seed.gs(:,2:M))/rho;
seed.ge(:,1:M-1)=seed.ge(:,1:M-1)+ ...
    rho*(Xe(:,1:M-1)-seed.z);
seed.gs(:,2:M)=seed.gs(:,2:M)+ ...
    rho*(Xs(:,2:M)-seed.z);
r2=sum(sum((Xe(:,1:M-1)-seed.z).^2))+ ...
   sum(sum((Xs(:,2:M)-seed.z).^2));
r=sqrt(r2);
s=sqrt(2)*rho*norm(seed.z-old_z,'fro');
ncopy=2*nx*(M-1);
num2=sum(sum(Xe(:,1:M-1).^2))+sum(sum(Xs(:,2:M).^2));
gam2=sum(sum(seed.ge(:,1:M-1).^2))+ ...
     sum(sum(seed.gs(:,2:M).^2));
epr=sqrt(ncopy)*cfg.tol_abs+cfg.tol_rel* ...
    max(sqrt(num2),sqrt(2)*norm(seed.z,'fro'));
epd=sqrt(ncopy)*cfg.tol_abs+cfg.tol_rel*sqrt(gam2);
seed.count=seed.count+1;
info.r_pr=r;info.r_du=s;info.eps_pr=epr;info.eps_du=epd;
info.iter=seed.count;
info.converged=(r<=epr && s<=epd);
info.kkt=kkt_stationarity(blocks,seed.dw, ...
    seed.gs,seed.ge,seed.lg,seed.lx);
% Optional rho adaptation. Disabled by default to stay closer to the article.
if cfg.rho_adapt && mod(seed.count,cfg.rho_every)==0
    if r/max(epr,eps)>cfg.rho_mu*s/max(epd,eps)
        rho=min(rho_max,rho*cfg.rho_tau);
    elseif s/max(epd,eps)>cfg.rho_mu*r/max(epr,eps)
        rho=max(rho_min,rho/cfg.rho_tau);
    end
    % gamma is UNSCALED and must not be rescaled after changing rho.
end
dw=seed.dw;
end

%% Helpers shared by the two research prototypes
function lambda_new=shift_consensus_dual(lambda_old,bs,damp)
% Heuristic MPC shift of duals; NOT covered by either convergence theorem.
[nx,nb]=size(lambda_old);lambda_new=zeros(nx,nb);
eta=1/max(1,bs);
for j=1:nb
    a=lambda_old(:,j); b=lambda_old(:,min(nb,j+1));
    lambda_new(:,j)=damp*((1-eta)*a+eta*b);
end
end

function [dq,residual]=reconstruct_intrinsic(stage,du)
% Tangent trajectory from the ADMM controls: satisfy all linearized dynamics.
N=size(du,2);nx=size(stage{1}.Dcur,2);
dq=zeros(nx,N+1);residual=0;
for k=1:N
    E=stage{k}.Dnext;
    rhs=-stage{k}.h0-stage{k}.Dcur*dq(:,k)-stage{k}.Du*du(:,k);
    if rcond(full(E))<1e-12
        residual=inf;return;
    end
    dq(:,k+1)=E\rhs;
    r=stage{k}.h0+stage{k}.Dcur*dq(:,k)+ ...
        E*dq(:,k+1)+stage{k}.Du*du(:,k);
    residual=max(residual,norm(full(r),inf));
end
end

function slope=trajectory_slope(stage,dq,du)
slope=0;
nt=size(dq,1);N=size(du,2);
for k=1:N
    v=[dq(:,k);zeros(nt,1);du(:,k)];
    slope=slope+stage{k}.grad_f(:)'*v;
end
end

function [du,gap]=local_controls_and_gap(blocks,dw,z,nu,bs)
M=numel(blocks);du=zeros(nu,M*bs);gap=0;
for i=1:M
    b=blocks{i};wi=dw{i};k0=(i-1)*bs;
    du(:,k0+(1:bs))=reshape(wi(b.u_off+(1:nu*bs)),nu,bs);
    if i<M
        gap=max(gap,norm(b.L_e*wi-z(:,i),inf));
    end
    if i>1
        gap=max(gap,norm(b.L_s*wi-z(:,i-1),inf));
    end
end
end

function [z,gap,rpr]=interface_metrics(blocks,dw)
M=numel(blocks);nx=size(blocks{1}.L_e,1);
z=zeros(nx,M-1);gap=0;r2=0;
for j=1:M-1
    a=blocks{j}.L_e*dw{j};b=blocks{j+1}.L_s*dw{j+1};
    z(:,j)=.5*(a+b);
    gap=max(gap,norm(a-b,inf));
    r2=r2+norm(a-b,2)^2;
end
rpr=sqrt(r2);
end

function [x_new,u_new,m_new,alpha,ok,kind]=try_reduced_trial( ...
    f_dyn,xplant,xbar,ubar,stage,dq,du,merit0, ...
    xr,ur,Q,R,k1,k2,idxb,xmin,xmax,sigma,umin,umax, ...
    use_ls,alpha0,alpha_min,beta,max_ls,armijo)
% Reuse the original nonlinear rollout/merit and input projection.
% For inexact ADMM use rollout directly; do NOT force inconsistent state copies.
[u_new,x_new,m_new,alpha,ok,kind]=update_nlp_exponential( ...
   f_dyn,xplant,xbar,ubar,dq,du,stage,merit0, ...
   xr,ur,Q,R,k1,k2,idxb,xmin,xmax, ...
   sigma,umin,umax,use_ls,alpha0,alpha_min,beta,max_ls,armijo,false);
end

function [w,lamg,lamx,ok,msg]=solve_local_qp(qp,b,H,f,x0)
% qpoases convention: lam_g multiplies g<=ub (and lb<=g), lam_x the bounds.
w=[];lamg=[];lamx=[];ok=false;msg='';
try
    sol=qp('x0',x0,'p',[f;H(:);b.A_all(:)], ...
        'lbx',b.lb,'ubx',b.ub, ...
        'lbg',[b.b_eq;-inf(b.n_ineq,1)], ...
        'ubg',[b.b_eq;b.b_ineq]);
    st=qp.stats();
    if isfield(st,'success') && ~st.success
        error('qpoases retornou success=false');
    end
    w=full(sol.x);
    assert(numel(w)==b.n_w && all(isfinite(w)));
    err=norm(b.A_eq*w-b.b_eq,inf);
    if err>max(1e-5,1e-5*norm(b.b_eq,inf))
        error('Igualdade local da dinamica nao satisfeita (%.2e)',err);
    end
    try
        lamg=full(sol.lam_g);lamx=full(sol.lam_x);
    catch
        lamg=nan(b.n_eq+b.n_ineq,1);lamx=nan(b.n_w,1);
    end
    ok=true;
catch ME
    msg=ME.message;
end
end

function residual=kkt_stationarity(blocks,dw,dual_left,dual_right,lamg,lamx)
% Residual of the convexified QP with coupling duals, not NLP Newton eq.(9).
ss=0;nn=0;
for i=1:numel(blocks)
    b=blocks{i};wi=dw{i};
    if any(~isfinite(lamg{i})) || any(~isfinite(lamx{i}))
        residual=NaN;return;
    end
    r=b.H*wi+b.f+b.A_all'*lamg{i}+lamx{i};
    if i>1,r=r+b.L_s'*dual_left(:,i);end
    if i<numel(blocks),r=r+b.L_e'*dual_right(:,i);end
    ss=ss+norm(r)^2;nn=nn+norm(b.f)^2;
end
residual=sqrt(ss)/max(1,sqrt(nn));
end

%% ==================== RETRACAO EXPONENCIAL ====================
function xn = retract_state_exponential(x,eta)
% x: 30 estados fisicos, eta: 20 incrementos INTRINSECOS.
% Convencao SO2: c=R11=cos(theta), s=R13=sin(theta).
assert(numel(x)==30 && numel(eta)==20);
x=x(:); eta=eta(:);
xn=x;
xn(1:13)=x(1:13)+eta(1:13);

% SO(3) do corpo: multiplicacao a direita pelo exp(so3).
Rk=reshape(x(14:22),3,3);
v=eta(14:16);
K=[ 0, -v(3), v(2); v(3), 0, -v(1); -v(2), v(1), 0 ];
Rn=Rk*expm(K);
xn(14:22)=Rn(:);

% SO(2)^4: exponencial exata por seno/cosseno.
for j=1:4
    ii=23+2*(j-1);
    c=x(ii); s=x(ii+1);
    ct=cos(eta(16+j)); st=sin(eta(16+j));
    xn(ii:ii+1)=[ct*c-st*s;st*c+ct*s];
end
end

%% ==================== MERITO COM DINAMICA ====================
function [J,defect] = merit_geometrico(f_dyn,xtr,u,xr,ur,Q,R,k1,k2, ...
                                      idx_bnd,x_min_b,x_max_b,sigma)
% Usa distancias que NAO anulam artificialmente em rotações de 180 graus.
% A integracao numerica nominal e IntegrationEuler + projecao no grupo,
% como na rotina simulate_plant() da versao original.
J=merit_trajectory(xtr,u,xr,ur,Q,R,k1,k2, ...
                   idx_bnd,x_min_b,x_max_b,sigma);
defect=0;
N=size(u,2);
for k=1:N
    xp=project_lie_state(full(f_dyn(xtr(:,k),u(:,k))));
    xn=xtr(:,k+1);
    if any(~isfinite(xp)) || any(~isfinite(xn))
        J=inf; defect=inf; return;
    end
    defect=defect+norm(xn(1:13)-xp(1:13),1);
    Rp=reshape(xp(14:22),3,3);
    Rn=reshape(xn(14:22),3,3);
    % Distancia cordal globalmente discriminante (zero apenas se iguais).
    defect=defect+norm(Rp-Rn,'fro');
    for j=1:4
        ii=23+2*(j-1);
        defect=defect+norm(xp(ii:ii+1)-xn(ii:ii+1),2);
    end
end
J=J+sigma*defect;
end

%% ==================== LINE SEARCH + RESTAURACAO DE VIABILIDADE ====================
function [u_new,x_new,merit_new,alpha_used,accepted,kind] = ...
    update_nlp_exponential( ...
      f_dyn,x_plant,x_bar,u_bar,dq,du,stage,merit0, ...
      xr,ur,Q,R,k1,k2,idx_bnd,x_min_b,x_max_b, ...
      sigma,u_min,u_max,use_ls,alpha0,alpha_min,beta,max_ls,armijo_c,try_exp)
% Primeiro tenta o passo geometico de multiple-shooting. Se o ADMM ainda
% apresenta desacordo ou o passo produz defeitos dinamicos, restaura
% a viabilidade com rollout da PLANTA DISCRETA (controle por shooting).
N=size(u_bar,2);
assert(isequal(size(dq),[20 N+1]) && isequal(size(du),size(u_bar)));
u_new=u_bar; x_new=x_bar; merit_new=merit0;
alpha_used=0; accepted=false; kind='none';

slope=0;
for k=1:N
    step=[dq(:,k);dq(:,k+1);du(:,k)];
    slope=slope+stage{k}.grad_f(:)'*step;
end
if ~isfinite(slope), return; end

maxSO3=max(sqrt(sum(dq(14:16,:).^2,1)));
maxSO2=max(max(abs(dq(17:20,:))));
maxAngle=max(maxSO3,maxSO2);
angleLimit=0.5;
if ~use_ls, max_ls=1; end
alpha=alpha0;
for j=1:max_ls
    if alpha<alpha_min && use_ls, break; end
    if try_exp && alpha*maxAngle>angleLimit
        alpha=alpha*beta;
        continue;
    end
    ut=project_controls(u_bar+alpha*du,u_min,u_max);
    if norm(ut-u_bar,'fro')<1e-13
        alpha=alpha*beta;
        continue;
    end
    % Opcao A: somente se a QP atingiu consenso suficiente.
    % Inexato: ir DIRETO para rollout, reduzindo exponenciais e defeitos.
    if try_exp
    xt=x_bar;
    xt(:,1)=x_plant;
    for k=2:N+1
        xt(:,k)=retract_state_exponential(x_bar(:,k),alpha*dq(:,k));
    end
    if all(isfinite(xt(:)))
        [mt,defect]=merit_geometrico(f_dyn,xt,ut,xr,ur,Q,R,k1,k2, ...
                       idx_bnd,x_min_b,x_max_b,sigma);
        req=merit0-armijo_c*alpha*max(0,-slope);
        % Exigir viabilidade dinamica para nao provocar h0 grande na
        % segunda SQP; com ADMM inexato, a retracao pode violar dinamica.
        if isfinite(mt) && defect<=1e-5 && ...
                bounds_guard(xt,x_bar,idx_bnd,x_min_b,x_max_b,1e-6) && ...
                mt<=req+1e-10
            u_new=ut; x_new=xt; merit_new=mt;
            alpha_used=alpha; accepted=true; kind='exponencial';
            return;
        end
    end
    end % try_exp
    % Opcao B: restaurar dinamica NAO LINEAR e preservar geometria pelo
    % integrador/projecao. A QP continuou sendo resolvida sem condensar.
    xr_trial=simulate_plant(f_dyn,x_plant,ut);
    mr=merit_trajectory(xr_trial,ut,xr,ur,Q,R,k1,k2, ...
                        idx_bnd,x_min_b,x_max_b,sigma);
    % A derivada direcional da SQP multiple-shooting nao corresponde
    % necessariamente ao merito do shooting restaurado. Portanto aceitar
    % uma reducao verificada do merito real, sem Armijo enganoso.
    if isfinite(mr) && ...
            bounds_guard(xr_trial,x_bar,idx_bnd,x_min_b,x_max_b,1e-6) && ...
            mr < merit0-1e-10*max(1,abs(merit0))
        u_new=ut; x_new=xr_trial; merit_new=mr;
        alpha_used=alpha; accepted=true; kind='restaurado';
        return;
    end
    alpha=alpha*beta;
end
end

%% ==================== RECUPERACAO DE DESCIDA ====================
function [u_new,x_new,m_new,alpha_used,ok] = fallback_shooting_gradient( ...
    f_dyn,xplant,xbar,ubar,stage,merit0, ...
    xr,ur,Q,R,k1,k2,idx_bnd,xmin,xmax,sigma,umin,umax,max_ls,beta)
% Gradiente reduzido aproximado obtido por adjunto discreto sobre
% Jh da dinamica intrinseca. Usado SOMENTE se a direcao ADMM falha.
N=size(ubar,2);
nu=size(ubar,1);
nt=size(stage{1}.Dcur,2);
p=zeros(nt,1);
g=zeros(nu,N);
for k=N:-1:1
    Dc=stage{k}.Dcur;
    Dn=stage{k}.Dnext;
    Du=stage{k}.Du;
    Ak=-(Dn\Dc);
    Bk=-(Dn\Du);
    gf=stage{k}.grad_f(:);
    % custo depende do estado atual e do controle; sem custo terminal
    g(:,k)=gf(2*nt+(1:nu))+Bk'*p;
    p=gf(1:nt)+Ak'*p;
end
u_new=ubar;
x_new=xbar;
m_new=merit0;
alpha_used=0;
ok=false;
if any(~isfinite(g(:))) || norm(g(:),inf)<1e-12, return; end

% Escalonamento por amplitude de controle: forcas e torques
range=max(umax-umin,1e-4);
cap=max(0.01,0.05*range);
dir=-bsxfun(@times,range.^2,g);
normscale=max(max(abs(bsxfun(@rdivide,dir,cap))));
if normscale<1e-14, return; end
dir=dir/max(1,normscale);

alpha=1;
for j=1:max(max_ls,12)
    ut=project_controls(ubar+alpha*dir,umin,umax);
    if norm(ut-ubar,'fro')<1e-13
        alpha=alpha*beta; continue;
    end
    xt=simulate_plant(f_dyn,xplant,ut);
    mt=merit_trajectory(xt,ut,xr,ur,Q,R,k1,k2, ...
                        idx_bnd,xmin,xmax,sigma);
    if isfinite(mt) && bounds_guard(xt,xbar,idx_bnd,xmin,xmax,1e-6) && ...
            mt < merit0-1e-10*max(1,abs(merit0))
        u_new=ut; x_new=xt; m_new=mt;
        alpha_used=alpha; ok=true;
        return;
    end
    alpha=alpha*beta;
end
end

function J = merit_trajectory(xtr,u,xr,ur,Q,R,k1,k2, ...
                              idx_bnd,x_min_b,x_max_b,sigma)
J = cost_traj(xtr,u,xr,ur,Q,R,k1,k2);
X = xtr(idx_bnd,:);
v_lower = bsxfun(@minus,x_min_b,X);
v_upper = bsxfun(@minus,X,x_max_b);
v = sum(max(v_lower(:),0))+sum(max(v_upper(:),0));
J = J + sigma*v;
end

function ok=hard_bounds_ok(xtr,idx_bnd,xmin,xmax,tol)
% Viabilidade pontual dos estados em TODOS os nos da trajetoria.
X=xtr(idx_bnd,:);
lo=bsxfun(@minus,X,xmin);
hi=bsxfun(@minus,xmax,X);
ok=all(isfinite(X(:))) && min(lo(:))>=-tol && min(hi(:))>=-tol;
end

function ok=bounds_guard(xnew,xbase,idx_bnd,xmin,xmax,tol)
% Se o warm-start e viavel, exige manter viabilidade. Caso contrario,
% permite APENAS restauracao que reduza a violacao total sem piorar maxima.
% Nao e garantia de seguranca para estado inicialmente inviavel.
[vs0,vm0]=state_bound_violation(xbase,idx_bnd,xmin,xmax);
[vs1,vm1]=state_bound_violation(xnew,idx_bnd,xmin,xmax);
if vs0<=tol
    ok=isfinite(vs1) && vs1<=tol;
else
    ok=isfinite(vs1) && vs1<vs0-1e-9*max(1,vs0) && vm1<=vm0+tol;
end
end

function [total,vmax]=state_bound_violation(xtr,idx_bnd,xmin,xmax)
X=xtr(idx_bnd,:);
lo=max(0,bsxfun(@minus,xmin,X));
hi=max(0,bsxfun(@minus,X,xmax));
v=[lo(:);hi(:)];
if any(~isfinite(v))
    total=inf;vmax=inf;
else
    total=sum(v);vmax=max(v);
end
end

function u = project_controls(u,u_min,u_max)
u = bsxfun(@max,u,u_min);
u = bsxfun(@min,u,u_max);
end

%% ==================== HESSIANA PARA QPOASES ====================
function [Hreg,delta] = convexify_hessian(H,eig_floor,delta_base)
% qpoases resolve QP escalar: sua Hessiana relevante e simetrica.
% Regularizacao para manter as QPs locais convexas.
H=0.5*(H+H');
if any(~isfinite(H(:)))
    error('Hessiana SQP nao finita. Corrija a modelagem/custo.');
end
lambda_min = min(eig(H));
delta = max(delta_base,eig_floor-lambda_min);
Hreg = H + delta*eye(size(H));
Hreg = 0.5*(Hreg+Hreg');
end

%% ==================== CUSTOS ====================
function J = cost_stage_sym(x,u,xr,ur,Q,R,k1,k2)
phi_B  = Attitude_error(x(14:22),xr(14:22),k1,k2);
phi_a2 = Attitude_error(x(23:24),xr(23:24),k1,k2);
phi_a3 = Attitude_error(x(25:26),xr(25:26),k1,k2);
phi_a4 = Attitude_error(x(27:28),xr(27:28),k1,k2);
phi_a5 = Attitude_error(x(29:30),xr(29:30),k1,k2);
x_ = [x(1:13)-xr(1:13);phi_B;phi_a2;phi_a3;phi_a4;phi_a5];
J = x_'*Q*x_+(u-ur)'*R*(u-ur);
end

function J = cost_traj(xtr,u,xr,ur,Q,R,k1,k2)
N = size(u,2);
J = 0;
for k = 1:N
    J = J + cost_stage_num(xtr(:,k),u(:,k),xr,ur,Q,R,k1,k2);
end
end

function J = cost_stage_num(x,u,xr,ur,Q,R,k1,k2)
phi_B  = Attitude_error(x(14:22),xr(14:22),k1,k2);
phi_a2 = Attitude_error(x(23:24),xr(23:24),k1,k2);
phi_a3 = Attitude_error(x(25:26),xr(25:26),k1,k2);
phi_a4 = Attitude_error(x(27:28),xr(27:28),k1,k2);
phi_a5 = Attitude_error(x(29:30),xr(29:30),k1,k2);
x_ = [x(1:13)-xr(1:13);phi_B;phi_a2;phi_a3;phi_a4;phi_a5];
J = x_'*Q*x_+(u-ur)'*R*(u-ur);
end

%% =========== RESTRICOES POR ESTAGIO, GRADIENTE GLOBAL ==============
function stage = prepare_geometric_stages(geo,g_global,xbar,ubar)
% Para o custo atual ell(x_k,u_k), o gradiente do estagio k e extraido
% diretamente de g_global. Nao existe custo em x_(k+1) nesse estagio.
% As Jacobianas h e g sao calculadas por estagio por eficiência.
N=size(ubar,2);
nt=geo.nx_t; nu=size(ubar,1);
assert(numel(g_global)==nt*(N+1)+nu*N);
stage=cell(N,1);
for k=1:N
    [Jh,h0,Jg,g0]=geo.lin(xbar(:,k),xbar(:,k+1),ubar(:,k));
    gf=[g_global((k-1)*nt+(1:nt)); ...
        zeros(nt,1); ...
        g_global(nt*(N+1)+(k-1)*nu+(1:nu))];
    stage{k}.Dcur=Jh(:,1:nt);
    stage{k}.Dnext=Jh(:,nt+(1:nt));
    stage{k}.Du=Jh(:,2*nt+(1:nu));
    stage{k}.h0=h0(:);
    stage{k}.Jg=Jg;
    stage{k}.g0=g0(:);
    stage{k}.grad_f=gf;
end
end

%% ================ QP LOCAL NAO CONDENSADA: T_i ===================
function b = build_block(i,M,bs,x_bar,u_bar,stage,geo, ...
                         H_global,g_global,idx_bnd,x_min_b,x_max_b,u_min,u_max,trust_du)
% A variavel global tem 20*(N+1)+8*N coordenadas:
% omega=[dq0;...;dqN;du0;...;du(N-1)].
% A variavel w_i da QP local e [dq_0;...;dq_bs;du_0;...;du_(bs-1)].
%
% T_i e a matriz de injecao 1420x76 definida por T_i(ids_global(j),j)=1.
% Portanto, T_i'*H_global*T_i == H_global(ids_global,ids_global).
% NAO precisa materializar T_i para montar a QP.
%
% Importante: como o custo original e ell(x_k,u_k) (NAO depende de x_next),
% a contribuicao do estado compartilhado no F GLOBAL pertence exclusivamente
% ao bloco que COMECA nesse estado. Por isso o ultimo estado dos blocos
% 1,...,M-1 nao recebe custo naquele bloco. O estado continua variavel e
% continua presente nas restricoes de dinamica e consenso.
nx=geo.nx_t; nu=size(u_bar,1);
N=size(u_bar,2);
k0=(i-1)*bs;
nstate=nx*(bs+1);
n_w=nstate+nu*bs;
n_eq=nx*bs;
nb=numel(idx_bnd);
n_ineq=2*nb*(bs+1);

% Indices da extracao GLOBAL (equivalente a T_i).
ids_global=zeros(n_w,1);
for j=0:bs
    ilocal=j*nx+(1:nx);
    iglobal=(k0+j)*nx+(1:nx);
    ids_global(ilocal)=iglobal;
end
for j=1:bs
    ilocal=nstate+(j-1)*nu+(1:nu);
    iglobal=nx*(N+1)+(k0+j-1)*nu+(1:nu);
    ids_global(ilocal)=iglobal;
end
assert(numel(unique(ids_global))==n_w);
H=full(H_global(ids_global,ids_global));
f=full(g_global(ids_global)); f=f(:);

if i<M
    ixend=bs*nx+(1:nx);
    % Validar que ell(x_k,u_k) nao possui acoplamento entre x_end e
    % variaveis de estagios anteriores dentro deste bloco. Se isto ocorrer,
    % a atribuicao do custo precisara ser generalizada (p.ex., custo x_next).
    other=setdiff(1:n_w,ixend);
    crossnorm=norm(H(ixend,other),'fro')+norm(H(other,ixend),'fro');
    assert(crossnorm<1e-8*max(1,norm(H,'fro')), ...
        ['Custo global possui acoplamento com fronteira final do bloco. ' ...
         'A decomposicao atual admite ell(x_k,u_k) sem acoplamento x_next.']);
    H(ixend,:)=0;
    H(:,ixend)=0;
    f(ixend)=0;
end

% Igualdades DINAMICAS explicitas: 20 por intervalo.
A_eq=zeros(n_eq,n_w);
b_eq=zeros(n_eq,1);
for j=1:bs
    st=k0+j;
    ixcur=(j-1)*nx+(1:nx);
    ixnext=j*nx+(1:nx);
    iu=nstate+(j-1)*nu+(1:nu);
    rr=(j-1)*nx+(1:nx);
    A_eq(rr,ixcur)=stage{st}.Dcur;
    A_eq(rr,ixnext)=stage{st}.Dnext;
    A_eq(rr,iu)=stage{st}.Du;
    b_eq(rr)=-stage{st}.h0(:);
end

% Limites de incremento dos controles.
lb=-inf(n_w,1); ub=inf(n_w,1);
for j=1:bs
    st=k0+j;
    iu=nstate+(j-1)*nu+(1:nu);
    lb(iu)=max(u_min-u_bar(:,st),-trust_du);
    ub(iu)=min(u_max-u_bar(:,st), trust_du);
end
if i==1
    lb(1:nx)=0;
    ub(1:nx)=0;
end

% Desigualdades de ESTADO por bloco: 2*13*(bs+1).
A_ineq=zeros(n_ineq,n_w);
b_ineq=zeros(n_ineq,1);
for j=0:bs
    knode=k0+j+1;
    ix=j*nx+(1:nx);
    [gk,Jgk]=geo.bound_eval(x_bar(:,knode));
    rr=2*nb*j+(1:2*nb);
    if i==1 && j==0
        % Estado inicial MEDIDO e FIXO: nao se pode impor sua correcao.
        % Se estiver fora da caixa, a restauracao trata o problema.
        A_ineq(rr,:)=0;
        b_ineq(rr)=inf;
    else
        A_ineq(rr,ix)=Jgk;
        b_ineq(rr)=-gk(:);
    end
end

Ls=zeros(nx,n_w);Le=zeros(nx,n_w);
Ls(:,1:nx)=eye(nx);
Le(:,bs*nx+(1:nx))=eye(nx);

b=struct();
b.H=H;b.f=f;
b.A_eq=A_eq;b.b_eq=b_eq;
b.A_ineq=A_ineq;b.b_ineq=b_ineq;
b.A_all=[A_eq;A_ineq];
b.n_eq=n_eq;b.n_ineq=n_ineq;b.n_w=n_w;
b.u_off=nstate;b.lb=lb;b.ub=ub;
b.L_s=Ls;b.L_e=Le;
b.has_x_start=(i>1);
b.block_id=i;
b.global_ids=ids_global;
end

%% ==================== SIMULACAO NAO LINEAR ====================
function x = simulate_plant(f_dyn,x0,u)
N = size(u,2);
nx = numel(x0);
x = zeros(nx,N+1);
x(:,1)=project_lie_state(x0);
for j=1:N
    x(:,j+1)=project_lie_state(full(f_dyn(x(:,j),u(:,j))));
end
end

function x = project_lie_state(x)
% Reprojeta SO(3) e normaliza os quatro pares SO(2) apos integracao.
% Para a formulacao SQP, isso mantem a trajetoria nominal sobre SO(3).
% A projecao polar/normalizacao altera a dinamica discreta da planta
% e deve ser omitida se IntegrationEuler ja tiver integrador geometrico.
% Valida a representacao SO(3) + quatro SO(2) como pares [R11;R13].
R=reshape(x(14:22),3,3);
[U,~,V]=svd(R);
D_rot=diag([1,1,sign(det(U*V'))]);
Rp=U*D_rot*V';
x(14:22)=Rp(:);
% SO(2): cada par q=[R11;R13]=[cos(theta);sin(theta)].
% Se o modelo utiliza R13=-sin(theta), e necessario inverter a convencao
% do incremento angular no gerador de derivadas e no residual.
for j=0:3
    ids=23+2*j+(0:1);
    q=x(ids);
    nq=hypot(q(1),q(2));
    if ~isfinite(nq) || nq<1e-10
        error('Par angular %d invalido: Init/IntegrationEuler deve fornecer [R11;R13] nao nulo.',j+1);
    end
    x(ids)=q/nq;
end
end

%% ==================== SOLVER QP CASADI ====================
function solver = make_qpsol(name,n_w,n_eq,n_ineq)
% A QP recebe simultaneamente igualdades de dinamica e desigualdades.
% Ela NAO condensa nem elimina estados.
import casadi.*
ncons=n_eq+n_ineq;
w=MX.sym('w',n_w);
p=MX.sym('p',n_w+n_w*n_w+ncons*n_w);
gv=p(1:n_w);
Hm=reshape(p(n_w+1:n_w+n_w*n_w),n_w,n_w);
Am=reshape(p(n_w+n_w*n_w+1:end),ncons,n_w);
qp=struct('x',w,'p',p,'f',0.5*w'*Hm*w+gv'*w,'g',Am*w);
opts=struct('printLevel','none','error_on_fail',false);
solver=qpsol(name,'qpoases',qp,opts);
end
