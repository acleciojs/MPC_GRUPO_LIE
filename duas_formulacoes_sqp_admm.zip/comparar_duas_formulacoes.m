% Benchmark com mesmos parametros e o mesmo modelo/custo para os dois metodos.
% Execute da pasta do modelo original com CasADi/qpoases no path.
clc;
cfg=struct('T_sim',20,'N',40,'M',8,'dt',0.01, ...
           'max_sqp',2,'plot_results',false);
A=nmpc_multirotor_sqp_admm_stomberg(cfg);
B=nmpc_multirotor_sqp_admm_liu_jian(cfg);
fprintf('\n=== COMPARACAO (NAO PROVA DE CONVERGENCIA) ===\n');
fprintf('Stomberg: err=%g, mediana tempo=%g s, ADMM/inst=%g\n', ...
    A.err(end),median(A.time),median(A.inner));
fprintf('Liu-Jian: err=%g, mediana tempo=%g s, varreduras/inst=%g\n', ...
    B.err(end),median(B.time),median(B.inner));
figure('Name','Comparacao SQP-ADMM');
plot(0:cfg.T_sim,A.err,'LineWidth',1.4);hold on;
plot(0:cfg.T_sim,B.err,'LineWidth',1.4);
grid on;xlabel('Amostra MPC');ylabel('Erro de posicao');
legend('SQP+ADMM Stomberg','SQP-ADMM Bregman Liu-Jian');
