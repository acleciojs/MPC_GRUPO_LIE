# Duas formulacoes SQP-ADMM para multirrotor de 30 estados

Foram produzidos dois arquivos MATLAB independentes, a partir de `nmpc_multirotor_sqp_admm_feedback.m` fornecido na conversa:

1. **`nmpc_multirotor_sqp_admm_stomberg.m`** — SQP externa, QP congelada e ADMM de consenso interno, inspirada no artigo de Stomberg, Engelmann e Faulwasser (2022).
2. **`nmpc_multirotor_sqp_admm_liu_jian.m`** — um unico ciclo de relinearizacao SQP, varredura Gauss-Seidel de dois grupos (blocos temporais impares e pares), regularizacao proximal quadratica de Bregman e atualizacao dual, inspirada em Liu e Jian (2020).

## O que foi preservado sem alteracao

As duas implementacoes utilizam, como o codigo original, exatamente:

```matlab
obj_global = derivadas_globais_horizonte_NMPC( ...
    N,Q,R,k1,k2,hessian_backend,'jet2');
[H_global,g_global,F_bar] = obj_global.eval(x_bar,u_bar,x_r,u_hover);
geo = derivadas_restricoes_NMPC(amost,idx_bnd,x_min_b,x_max_b,u_min,u_max);
```

Tambem foram **copiadas sem modificacao** todas as funcoes auxiliares do arquivo original desde `RETRACAO EXPONENCIAL` ate `make_qpsol`, incluindo `build_block`, custos, integrador, limites, gradientes por estagio e convexificacao da Hessiana para QP. Os pesos Q e R sao identicos aos do codigo fornecido. As 20 coordenadas intrinsecas e a geometria SO(3) x SO(2)^4 tambem sao preservadas.

A Hessiana **permanece a Hessiana geometrica simetrica do custo**, nao a Hessiana da Lagrangiana completa. Portanto, a versao Stomberg e um metodo SQP de Hessiana aproximada e **nao** herda o teorema de Newton inexato do artigo. Os termos proximais em Liu-Jian alteram apenas a matriz quadratica da QP local (`H+P`) e **nao** alteram o gerador simbolico da Hessiana/gradiente.

## Execucao no MATLAB

Execute a partir da pasta do projeto original, com os arquivos auxiliares do modelo e CasADi disponiveis no caminho:

```matlab
cfg = struct('T_sim',20,'N',40,'M',8,'dt',0.01, ...
             'max_sqp',2,'plot_results',false);

A = nmpc_multirotor_sqp_admm_stomberg(cfg);
B = nmpc_multirotor_sqp_admm_liu_jian(cfg);

fprintf('Stomberg: err=%.3e, tempo=%.3fs, iter/inst=%.1f\n', ...
    A.err(end),median(A.time),median(A.inner));
fprintf('Liu/Jian: err=%.3e, tempo=%.3fs, sweeps/inst=%.1f\n', ...
    B.err(end),median(B.time),median(B.inner));
```

Ou execute `comparar_duas_formulacoes.m`.

Se o caminho do CasADi for outro:

```matlab
cfg.casadi_path = '/caminho/casadi';
```

## Stomberg — formula

Cada bloco temporal minimiza a QP convexificada do SQP sujeita a dinamica linearizada, limites de entrada e desigualdades de estado. Em cada iteracao interna:

- minimiza-se a Lagrangiana aumentada da QP para cada bloco;
- projeta-se a fronteira em consenso (media das duas copias);
- atualizam-se os multiplicadores nao escalados.

A cada 5 iteracoes (configuravel), o metodo calcula residuos ADMM, `gap`, estacionalidade da QP (com os multiplicadores de qpoases) e avalia uma direcao dinamicamente reconstruida por rollout nao linear. Pode encerrar cedo se a QP esta suficientemente boa e a melhora da funcao de merito e verificada. Se acabar o orcamento, pode admitir uma direcao *inexata validada* quando `gap < gap_emergency`; isso **nao** e chamado de convergencia do ADMM.

O orcamento de iteracoes comeca em `budget_initial=60`, vai diminuindo apenas apos sucessivas QPs bem resolvidas, e aumenta apos problemas.

O residuo KKT reportado e uma estimativa da estacionariedade da **QP convexificada**, nao a equacao (9) exata do artigo. A condicao de Newton inexato de Stomberg exige tambem o modelo KKT primal-dual completo da NLP e a Hessiana da Lagrangiana; nao se pode alegar que foi implementada literalmente enquanto se preserva a Hessiana do custo.

Configuracoes uteis:

```matlab
A = nmpc_multirotor_sqp_admm_stomberg(struct( ...
    'T_sim',20,'max_sqp',2,'budget_initial',60, ...
    'budget_max',150,'gap_early',0.1, ...
    'rho',15,'rho_adapt',false,'plot_results',false));
```

## Liu e Jian — formula

As variaveis locais dos M blocos sao particionadas em **dois grupos**, impares e pares, evitando o ADMM multi-bloco Jacobi. A cada iteracao global, para cada bloco do grupo corrente, minimiza-se:

\[
\frac12w_i^TH_iw_i+g_i^Tw_i
+\lambda^TC_iw_i+\frac\rho2\|C_iw_i-d_i\|^2
+\frac12\|w_i-w_i^{\rm old}\|^2_{P_i},
\]

com `P_i = bregman_tau * diag(max(bregman_floor, abs(diag(H_i))))`. As QPs retêm todas as restricoes locais existentes. Depois da varredura impar/par, ocorre a atualizacao dual das interfaces e o teste da direcao no rollout nao linear.

**Nao ha loop ADMM interno** nesta versao: uma varredura por iteracao SQP. O campo `B.inner` conta varreduras, enquanto `B.r_norm` registra o gap de interface bruto e `B.s_norm` o tamanho relativo do incremento, **nao** residuos ADMM com denominadores de tolerancia.

Configuracoes uteis:

```matlab
B = nmpc_multirotor_sqp_admm_liu_jian(struct( ...
    'T_sim',20,'max_sqp',4,'bregman_tau',0.03, ...
    'rho',15,'max_gap',2,'plot_results',false));
```

Essa extensao para desigualdades locais, dinamica nao linear, 8 blocos e grupos de Lie nao esta no escopo da prova de convergencia de Liu e Jian. O metodo e uma **adaptacao experimental**.

## Diagnosticos recomendados

- `err`: erro de posicao da planta apos aplicar somente o primeiro controle.
- `inner`: iteracoes internas ADMM (Stomberg) ou numero de varreduras SQP-ADMM (Liu/Jian).
- `gap`: desacordo de estados nas interfaces das QPs locais.
- `kkt`: norma relativa da estacionariedade da QP (com regularizacao, nao KKT completa da NLP).
- `r_norm`, `s_norm`: normalizados por tolerancias ADMM *somente na primeira versao*.
- `step_kind`: `admm-consenso-restaurado`, `admm-inexato-validado`, `bregman-gs-restaurado` ou `gradiente-restaurado`.
- `alpha`: parametro da busca linear; valores proximos de `2^-9` denotam estagnacao e precisam de diagnostico.
- `tangent_residual`: defeito da dinamica linearizada apos reconstruir os incrementos de estados a partir de controles.

## Limites e validacao

Foi realizada uma revisao estatica e um teste matematico isolado das atualizacoes de consenso/duais em um problema quadratico escalar, que recuperaram o otimo centralizado. **Nao foi executado o codigo MATLAB completo** porque as funcoes externas do seu multirrotor nao estao disponiveis neste ambiente. Nem estabilidade do MPC nem menor tempo de execucao estao comprovados.

Observacao: o horizonte original foi preservado em `N=40`, `dt=0.01` (**0,4 s**) para comparar apenas as formulacoes sem alterar o problema. Se desejar maior horizonte fisico, modifique N (ou adote uma discretizacao multirate separadamente).

**Artigos:** Stomberg, Engelmann e Faulwasser, *Decentralized non-convex optimization via bi-level SQP and ADMM*, CDC 2022; Liu e Jian, *An ADMM-based SQP method for separably smooth nonconvex optimization*, J. Inequalities and Applications 2020.
