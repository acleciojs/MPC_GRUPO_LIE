function [delta,info] = resolver_admm_qps(blocos,opts)
% RESOLVER_ADMM_QPS  ADMM ESCALAR OU PRECONDICIONADO POR INTERFACE.
% EXTERNA a sqp_lie_admm.m
%
% Cada bloco tem w_i, H_i, f_i, Aeq_i, Aineq_i, lb_i, ub_i.
% Interfaces: Le_i*w_i = z_i = Ls_(i+1)*w_(i+1).
% Multiplicadores gammae_i, gammas_(i+1) sao NAO escalados.
% rho fixo, sem Nesterov. P_i = rho*diag(p_i), com p_i>0.
% O MESMO P_i e usado nas duas copias da interface i.
% Modos opts.precond_mode: 'scalar', 'curvature', 'manual'.
% Em 'curvature', os pesos sao estimados pela diagonal de Hessianas
% RESTRITAS AOS INDICES DE INTERFACE (aproximacao, nao Schur exato),
% normalizados e limitados para robustez.
% Em 'manual', opts.precond_weights e um vetor por interface ou cell.
% Sem aceitacao inexata: exige r<=eps_pr, s<=eps_du e gap<=tol_gap.
% A QP central nao e alterada: precondicionamento atua APENAS no consenso.

M=numel(blocos);nvar=zeros(M,1);
for i=1:M,nvar(i)=blocos{i}.n;end
rho=opts.rho;
precond_mode=lower(char(field_or(opts,'precond_mode','scalar')));
assert(ismember(precond_mode,{'scalar','curvature','manual'}), ...
    'precond_mode deve ser scalar, curvature ou manual');
max_iter=opts.max_iter;
tol_abs=opts.tol_abs;tol_rel=opts.tol_rel;
tol_gap=field_or(opts,'tol_gap_inf',1e-5);
assert(isfinite(tol_gap) && tol_gap>0,'tol_gap_inf deve ser positivo');
assert(max_iter==round(max_iter) && max_iter>=1,'max_iter invalido');
assert(rho>0 && tol_abs>0 && tol_rel>=0,'rho/tol invalidos');

niface=M-1;
[metric_diag,metric_weights]=construir_metricas(blocos,rho,precond_mode,opts);
z=cell(niface,1);gamma_e=cell(niface,1);gamma_s=cell(niface,1);
for i=1:niface
    k=size(blocos{i}.Le,1);
    assert(k==size(blocos{i+1}.Ls,1),'Interface %d inconsistente',i);
    z{i}=zeros(k,1);gamma_e{i}=zeros(k,1);gamma_s{i}=zeros(k,1);
end
w=cell(M,1);
for i=1:M,w{i}=zeros(nvar(i),1);end

% H augmented nao muda durante esta QP: construir UMA VEZ para
% evitar recalcular produtos matriciais a cada iteracao ADMM.
Haug=cell(M,1);
qp_constant=cell(M,1);
for i=1:M
    b=blocos{i};Hi=b.H;
    if i>1
        pvec=metric_diag{i-1};L=b.Ls;
        Hi=Hi+L.'*(spdiags(pvec,0,numel(pvec),numel(pvec))*L);
    end
    if i<M
        pvec=metric_diag{i};L=b.Le;
        Hi=Hi+L.'*(spdiags(pvec,0,numel(pvec),numel(pvec))*L);
    end
    Haug{i}=full(0.5*(Hi+Hi.'));
    qp_constant{i}=[];
end

solver_name=lower(char(opts.solver));
assert(ismember(solver_name,{'quadprog','qpoases'}), ...
       'opts.solver deve ser quadprog ou qpoases');
qp_solver=cell(M,1);
if strcmp(solver_name,'qpoases')
    for i=1:M
        qp_solver{i}=construir_qpoases(blocos{i},i);
        A=[blocos{i}.Aeq;blocos{i}.Aineq];
        qp_constant{i}=[Haug{i}(:);full(A(:))];
    end
else
    assert(exist('quadprog','file')~=0, ...
       'quadprog nao esta disponivel. Selecione qp_solver=qpoases.');
    qpopts=optimoptions('quadprog', 'Display','off', ...
      'Algorithm','interior-point-convex', 'MaxIterations',400, ...
      'OptimalityTolerance',1e-9, 'ConstraintTolerance',1e-9);
end

info=struct('converged',false,'ok',true,'reason','max_iter', ...
    'iter',0,'r_pr',Inf,'r_du',Inf,'eps_pr',Inf,'eps_du',Inf, ...
    'gap_inf',Inf,'gap_threshold',tol_gap,'history',nan(max_iter,4), ...
    'precond_mode',precond_mode,'metric_weights',{metric_weights}, ...
    'metric_diag',{metric_diag}, ...
    'z',{z},'gamma_e',{gamma_e},'gamma_s',{gamma_s},'w',{w});

for iter=1:max_iter
    zold=z;
    % P1: resolver as QPs locais com z e duais CONGELADOS.
    for i=1:M
        b=blocos{i};Hi=Haug{i};ci=b.f;
        if i>1
            L=b.Ls;pvec=metric_diag{i-1};
            ci=ci+L.'*(gamma_s{i-1}-pvec.*z{i-1});
        end
        if i<M
            L=b.Le;pvec=metric_diag{i};
            ci=ci+L.'*(gamma_e{i}-pvec.*z{i});
        end
        try
            if strcmp(solver_name,'quadprog')
                [wi,~,flag,st]=quadprog(Hi,ci, ...
                    b.Aineq,b.bineq,b.Aeq,b.beq, ...
                    b.lb,b.ub,[],qpopts);
                if isempty(wi) || flag<=0
                    error('quadprog flag=%d: %s',flag,st.message);
                end
            else
                fparam=[ci;qp_constant{i}];
                lbA=[b.beq;-inf(numel(b.bineq),1)];
                ubA=[b.beq;b.bineq];
                solver_i=qp_solver{i};
                sol=solver_i('x0',zeros(b.n,1), ...
                    'p',fparam,'lbx',b.lb,'ubx',b.ub, ...
                    'lbg',lbA,'ubg',ubA);
                wi=full(sol.x);
                st=solver_i.stats();
                if isfield(st,'success') && ~st.success
                    error('CasADi qpOASES informou success=false');
                end
            end
            assert(all(isfinite(wi)) && numel(wi)==b.n, ...
                'QP local retornou valores invalidos');
            eqr=norm(b.Aeq*wi-b.beq,inf);
            ineqr=max([0;b.Aineq*wi-b.bineq;b.lb-wi;wi-b.ub]);
            if eqr>1e-6*max(1,norm(b.beq,inf)) || ineqr>1e-6
                error('QP local nao viavel: eq=%.3e ineq=%.3e',eqr,ineqr);
            end
            w{i}=wi(:);
        catch ME
            info.converged=false;info.ok=false;
            info.reason=sprintf('iter=%d, bloco=%d: %s',iter,i,ME.message);
            info.iter=iter;info.history=info.history(1:max(0,iter-1),:);
            info.w=w;info.z=z;info.gamma_e=gamma_e;info.gamma_s=gamma_s;
            delta=[];return;
        end
    end

    % P2: consenso corrigido pelos multiplicadores nao escalados.
    for i=1:niface
        xe=blocos{i}.Le*w{i};
        xs=blocos{i+1}.Ls*w{i+1};
        z{i}=0.5*(xe+xs)+0.5*((gamma_e{i}+gamma_s{i})./metric_diag{i});
    end
    % P3: multiplicadores para as duas copias de cada interface.
    for i=1:niface
        gamma_e{i}=gamma_e{i}+metric_diag{i}.*(blocos{i}.Le*w{i}-z{i});
        gamma_s{i}=gamma_s{i}+metric_diag{i}.*(blocos{i+1}.Ls*w{i+1}-z{i});
    end

    r2=0;s2=0;Ax2=0;Bz2=0;y2=0;
    gap_inf=0; ncopy=0;
    % Norma do residual dual usa A'*(rho*B*Delta z), nao apenas ||Dz||.
    for i=1:niface
        xe=blocos{i}.Le*w{i};
        xs=blocos{i+1}.Ls*w{i+1};
        re=xe-z{i};rs=xs-z{i};
        dz=z{i}-zold{i};
        r2=r2+sum(re.^2)+sum(rs.^2);
        Ax2=Ax2+sum(xe.^2)+sum(xs.^2);
        Bz2=Bz2+2*sum(z{i}.^2);
        pdz=metric_diag{i}.*dz;
        s2=s2+norm(blocos{i}.Le.'*pdz)^2 + ...
                 norm(blocos{i+1}.Ls.'*pdz)^2;
        gap_inf=max(gap_inf,max(abs(xe-xs)));
        ncopy=ncopy+2*numel(z{i});
    end
    for i=1:M
        y=zeros(blocos{i}.n,1);
        if i>1, y=y+blocos{i}.Ls.'*gamma_s{i-1};end
        if i<M, y=y+blocos{i}.Le.'*gamma_e{i};end
        y2=y2+norm(y)^2;
    end
    r_pr=sqrt(r2);r_du=sqrt(s2);
    eps_pr=sqrt(ncopy)*tol_abs+tol_rel*max(sqrt(Ax2),sqrt(Bz2));
    eps_du=sqrt(sum(nvar))*tol_abs+tol_rel*sqrt(y2);
    info.iter=iter;info.r_pr=r_pr;info.r_du=r_du;
    info.eps_pr=eps_pr;info.eps_du=eps_du;
    info.gap_inf=gap_inf;
    info.history(iter,:)=[r_pr,r_du,eps_pr,eps_du];
    if opts.verbose && (iter==1 || mod(iter,opts.verbose_every)==0)
        fprintf(' ADMM[%s]=%d | r/eps=%.3e | s/eps=%.3e | gap=%.3e (lim %.1e)\n', ...
                precond_mode,iter,r_pr/max(eps_pr,eps),r_du/max(eps_du,eps),gap_inf,tol_gap);
    end
    if r_pr<=eps_pr && r_du<=eps_du && gap_inf<=tol_gap
        info.converged=true;info.reason='converged';
        break;
    end
end
info.history=info.history(1:info.iter,:);
info.z=z;info.gamma_e=gamma_e;info.gamma_s=gamma_s;
info.w=w;
% Recuperacao por media das copias locais: consistente no limite primal.
n=max(cellfun(@(b)max(b.id),blocos));
sums=zeros(n,1);counts=zeros(n,1);
for i=1:M
    id=blocos{i}.id;
    sums(id)=sums(id)+w{i};
    counts(id)=counts(id)+1;
end
delta=sums./counts;
end


function [Pdiag,weights]=construir_metricas(blocos,rho,mode,opts)
% P_i = rho*diag(weights_i) com pesos positivos e FIXOS por QP.
% Os pesos usados em ambos os lados de uma interface sao identicos.
M=numel(blocos);ns=M-1;
Pdiag=cell(ns,1);weights=cell(ns,1);
clamp=field_or(opts,'precond_clamp',[0.2 5]);
assert(isnumeric(clamp) && numel(clamp)==2 && all(isfinite(clamp)) && ...
       clamp(1)>0 && clamp(2)>=clamp(1), ...
       'precond_clamp deve ser [min,max] com min>0');
power=field_or(opts,'precond_power',0.5);
assert(isscalar(power) && isfinite(power) && power>=0 && power<=1, ...
       'precond_power precisa estar em [0,1]');
for i=1:ns
    Le=blocos{i}.Le;Ls=blocos{i+1}.Ls;
    d=size(Le,1);
    assert(d>0 && size(Ls,1)==d,'Interface %d invalida',i);
    if strcmp(mode,'scalar')
        wi=ones(d,1);
    elseif strcmp(mode,'manual')
        W=field_or(opts,'precond_weights',[]);
        if iscell(W)
            assert(numel(W)==ns,'precond_weights: cell com %d interfaces',ns);
            wi=W{i}(:);
        elseif isvector(W) && ~isempty(W)
            wi=W(:);
        else
            error('precond_weights deve ser vetor positivo ou cell de vetores');
        end
        assert(numel(wi)==d && all(isfinite(wi)) && all(wi>0), ...
               'Pesos manuais invalidos na interface %d',i);
    else
        % Curvatura diagonal nos estados compartilhados (nao eh o Schur).
        He=blocos{i}.H; Hs=blocos{i+1}.H;
        ce=full(diag(Le*He*Le.'));
        cs=full(diag(Ls*Hs*Ls.'));
        assert(numel(ce)==d && numel(cs)==d, 'Diagonal nao encontrada');
        floor_curv=1e-12;
        ce=max(ce,floor_curv);cs=max(cs,floor_curv);
        raw=sqrt(ce.*cs);
        base=median(raw);
        wi=(raw/max(base,floor_curv)).^power;
        wi=min(clamp(2),max(clamp(1),wi));
    end
    Pdiag{i}=rho*wi;
    weights{i}=wi;
end
end

function solver=construir_qpoases(b,i)
import casadi.*
n=b.n;m=numel(b.beq)+numel(b.bineq);
w=MX.sym(sprintf('w%d',i),n);
p=MX.sym(sprintf('p%d',i),n+n*n+m*n);
grad=p(1:n);
H=reshape(p(n+(1:n*n)),n,n);
A=reshape(p(n+n*n+1:end),m,n);
problem=struct('x',w,'p',p,'f',0.5*w.'*H*w+grad.'*w,'g',A*w);
options=struct('printLevel','none','error_on_fail',false);
solver=qpsol(sprintf('qp_admm_bloco_%d',i),'qpoases',problem,options);
end

function v=field_or(s,key,def)
if isfield(s,key) && ~isempty(s.(key)),v=s.(key);else,v=def;end
end
