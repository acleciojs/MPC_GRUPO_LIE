# NMPC geométrico SQP–ADMM com orçamento adaptativo

Arquivo principal: `nmpc_multirotor_sqp_admm_adaptativo.m`.

## Execução

```matlab
r = nmpc_multirotor_sqp_admm_adaptativo(struct( ...
    'T_sim', 150, ...
    'N', 40, 'M', 8, 'dt', 0.01, ...
    'admm_initial', 48, ...
    'admm_steady', 8, ...
    'admm_maximum', 90, ...
    'admm_decay_samples', 30, ...
    'admm_gap_accept', 0.1, ...
    'admm_ratio_accept', 4, ...
    'dual_warm_factor', 0.8, ...
    'nesterov', false));
```

As dependências externas (`Init`, `Equilibrio`, `IntegrationEuler`, `Attitude_error`, derivadores geométricos, CasADi e qpOASES) permanecem necessárias.

## Política de orçamento

- Início: 48 iterações máximas por QP SQP; regime estável: 8; teto de emergência: 90.
- Decaimento nominal exponencial com constante 30 amostras.
- A redução para orçamento pequeno requer uma sequência de amostras em que uma direção tenha sido aceita **e** o ADMM alcançado `max(r/eps,s/eps)<=4` e `gap<=0.1`.
- Se a qualidade piorar, o orçamento volta a aumentar. Acima de 10 vezes a razão admissível, ele sobe pelo menos para 1,25 vezes o orçamento inicial.
- A QP é resolvida em lotes de 6 iterações, preservando consenso, duais e soluções locais de QP entre lotes.
- Interrompe antes do máximo por convergência completa ou por **passo MPC aceito com consistência suficiente**; não chama uma parada inexata de convergência.
- Sobre-relaxação 1,6; Nesterov desligado por padrão (experimental).

## Warm-start

- Controle: deslocamento do horizonte anterior, mais rollout não linear para obter trajetória nominal consistente.
- Dual: interpolação temporal e amortecimento de 0,8 sobre os multiplicadores não escalados das interfaces. Atualizados apenas se a solução das interfaces foi suficientemente consistente.
- Dentro da mesma QP: sementes `dw`, `z`, `gamma_s`, `gamma_e` são mantidas entre os lotes de ADMM.
- **Não** reutiliza diretamente incrementos primais de estado da linearização anterior como se fossem viáveis na nova linearização; isso exigiria transporte/recentragem no grupo e restauração das igualdades.

## Diagnóstico

Os logs agora incluem `budget` (limite de iterações daquela SQP) e `warm` (norma da semente dual). O retorno contém:

- `r.admm`: iterações realmente executadas, somadas sobre SQPs da amostra
- `r.admm_budget`: orçamento por SQP daquela amostra
- `r.r_norm`, `r.s_norm`, `r.gap`: precisão ADMM
- `r.admm_quality`: amostras com direção aceita e consistência suficiente
- `r.warm_dual`: norma da semente dual deslocada

```matlab
figure;
plot(r.admm,'DisplayName','ADMM executadas'); hold on;
plot(r.admm_budget,'DisplayName','orçamento por SQP');
grid on; legend;

figure;
semilogy(r.r_norm,'DisplayName','primal/tolerância'); hold on;
semilogy(r.s_norm,'DisplayName','dual/tolerância');
semilogy(r.gap,'DisplayName','gap');
grid on; legend;
```

Se usar `max_sqp>1`, `r.admm` pode ultrapassar `r.admm_budget`, porque este é o limite **por SQP** e o log `admm` soma todas as SQPs daquela amostra.

**Limitações:** os thresholds são heurísticos para aceitar direções inexatas; não constituem garantia de estabilidade ou convergência. Não foram executadas simulações completas porque as funções externas do multirrotor não estão disponíveis aqui. O log de redução de custo ainda precisa ser confrontado com a trajetória da planta e o erro de rastreamento.
